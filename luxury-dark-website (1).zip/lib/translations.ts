export type Language = "en" | "ur" | "ar" | "es" | "fr" | "de" | "hi" | "zh" | "pt" | "tr"

export const languageNames: Record<Language, string> = {
  en: "English",
  ur: "اردو",
  ar: "العربية",
  es: "Español",
  fr: "Français",
  de: "Deutsch",
  hi: "हिन्दी",
  zh: "中文",
  pt: "Português",
  tr: "Türkçe",
}

export const translations: Record<
  Language,
  {
    nav: {
      home: string
      services: string
      portfolio: string
      results: string
      contact: string
      freeCall: string
    }
    hero: {
      badge: string
      title: string
      titleHighlight: string
      subtitle: string
      description: string
      cta: string
      ctaSecondary: string
      happyClients: string
      rating: string
      engagement: string
      engagementLabel: string
      projects: string
      projectsLabel: string
      conversion: string
      conversionLabel: string
      turnaround: string
      turnaroundLabel: string
      brandGrowth: string
      rated: string
      revenueImpact: string
      monthlyGrowth: string
      thisMonth: string
    }
    problem: {
      badge: string
      title: string
      titleHighlight: string
      description: string
      bottomQuestion: string
      bottomSolution: string
      problems: {
        title: string
        description: string
        stat: string
        statLabel: string
      }[]
    }
    solution: {
      badge: string
      title: string
      description: string
      processTitle: string
      processSubtitle: string
      cta: string
      ctaSubtext: string
      solutions: {
        title: string
        description: string
        benefit: string
      }[]
      process: {
        title: string
        desc: string
      }[]
    }
    services: {
      badge: string
      title: string
      description: string
      benefitsTitle: string
      benefits: string[]
      servicesList: {
        title: string
        description: string
      }[]
    }
    footer: {
      description: string
      quickLinks: string
      servicesTitle: string
      getInTouch: string
      availableWorldwide: string
      copyright: string
      privacyPolicy: string
      termsOfService: string
    }
  }
> = {
  en: {
    nav: {
      home: "Home",
      services: "Services",
      portfolio: "Portfolio",
      results: "Results",
      contact: "Contact",
      freeCall: "Free Strategy Call",
    },
    hero: {
      badge: "Trusted by 50+ Brands Worldwide",
      title: "Is Your Brand",
      titleHighlight: "Invisible on Social Media?",
      subtitle: "Reality check:",
      description:
        "You're posting content, but getting zero engagement. Followers aren't growing. No sales coming in. I transform your brand with scroll-stopping designs and strategic content that grabs attention and converts customers.",
      cta: "Book Free Strategy Call",
      ctaSecondary: "View Portfolio",
      happyClients: "50+ Happy Clients",
      rating: "5.0 Rating",
      engagement: "Engagement",
      engagementLabel: "Average Increase",
      projects: "Projects",
      projectsLabel: "Completed",
      conversion: "Conversion",
      conversionLabel: "Client Retention",
      turnaround: "Turnaround",
      turnaroundLabel: "Delivery Time",
      brandGrowth: "Brand Growth After Working With Me",
      rated: "#1 Rated",
      revenueImpact: "Revenue Impact",
      monthlyGrowth: "Monthly Growth Trend",
      thisMonth: "+24% this month",
    },
    problem: {
      badge: "Is This Your Story?",
      title: "Why Are You",
      titleHighlight: "Struggling on Social Media?",
      description:
        "If you're facing these problems, you're not alone. 90% of businesses face the same challenges. But there's a solution - and I can give you exactly that.",
      bottomQuestion: "Are you facing these problems too?",
      bottomSolution: "Don't worry - solution is below",
      problems: [
        {
          title: "Invisible Posts",
          description: "Your posts don't grab attention in the first 3 seconds - the algorithm ignores you",
          stat: "70%",
          statLabel: "posts go unseen",
        },
        {
          title: "Generic Designs",
          description: "Canva templates all look the same - your brand gets lost in the crowd",
          stat: "89%",
          statLabel: "brands use same look",
        },
        {
          title: "Inconsistent Branding",
          description: "Every post looks different - customers are confused and trust isn't building",
          stat: "60%",
          statLabel: "lost trust due to inconsistency",
        },
        {
          title: "Likes But No Sales",
          description: "Getting engagement but no inquiries or sales - content strategy is missing",
          stat: "95%",
          statLabel: "content without strategy fails",
        },
        {
          title: "Wasted Budget",
          description: "Spending on ads but ROI is negative - targeting and creative both weak",
          stat: "$500+",
          statLabel: "monthly wasted on average",
        },
        {
          title: "Time Drain",
          description: "Hours spent on content creation but zero results - productivity loss",
          stat: "15+ hrs",
          statLabel: "weekly wasted on DIY content",
        },
      ],
    },
    solution: {
      badge: "Your Solution Is Here",
      title: "Strategic Design + Smart Content = Growth",
      description:
        "I'm not just a designer - I'm your growth partner. Every design has strategy behind it, every post has a goal. Result? Your brand on top.",
      processTitle: "Simple 4-Step Process",
      processSubtitle: "From confused to confident in just 4 steps",
      cta: "Book Your Free Strategy Call",
      ctaSubtext: "No commitment - just value",
      solutions: [
        {
          title: "Scroll-Stopping Visuals",
          description: "Designs that grab attention in first 0.5 seconds - algorithm approved",
          benefit: "5x more reach guaranteed",
        },
        {
          title: "Strategic Content Planning",
          description: "Every post with a purpose - journey planned from awareness to conversion",
          benefit: "Clear path to sales",
        },
        {
          title: "Premium Brand Identity",
          description: "Consistent and memorable brand look that builds trust and authority",
          benefit: "Stand out from competition",
        },
        {
          title: "Psychology-Based Design",
          description: "Colors, fonts and layouts scientifically proven to boost engagement",
          benefit: "Higher conversion rates",
        },
        {
          title: "Data-Driven Optimization",
          description: "Track performance and continuously improve content",
          benefit: "Month-over-month growth",
        },
        {
          title: "Fast Turnaround",
          description: "Professional content delivery in 48 hours - no more waiting",
          benefit: "Never miss a trend",
        },
      ],
      process: [
        { title: "Discovery Call", desc: "Understanding your brand and goals" },
        { title: "Strategy Plan", desc: "Develop custom content strategy" },
        { title: "Design & Create", desc: "Create premium content" },
        { title: "Launch & Grow", desc: "Track and optimize results" },
      ],
    },
    services: {
      badge: "My Services",
      title: "What I Can Do for Your Brand",
      description:
        "I offer complete social media content and design solutions so you can focus on your business while I handle your online presence.",
      benefitsTitle: "What You Gain by Working With Me",
      benefits: [
        "Strong and professional brand presence",
        "Higher engagement and reach",
        "Content that attracts the right audience",
        "Better conversion from social media",
        "Time saved with done-for-you content",
        "Clear strategy instead of random posting",
      ],
      servicesList: [
        {
          title: "Social Media Content Creation",
          description:
            "Post ideas, content direction, and visual planning designed to grow engagement and brand awareness.",
        },
        {
          title: "Graphic Design for Social Media",
          description:
            "Professional posts, carousels, stories, and ad creatives that stop the scroll and elevate your brand image.",
        },
        {
          title: "Brand Visual Identity",
          description:
            "Consistent colors, typography, and layout style to make your brand recognizable and trustworthy.",
        },
        {
          title: "Ad Creative Design",
          description: "High-converting creatives designed to improve clicks, inquiries, and campaign performance.",
        },
        {
          title: "Content Planning Support",
          description:
            "Structured visual planning so your social media stays consistent, professional, and growth-focused.",
        },
      ],
    },
    footer: {
      description:
        "Scroll-stopping visuals and strategic content that converts attention into engagement and engagement into results.",
      quickLinks: "Quick Links",
      servicesTitle: "Services",
      getInTouch: "Get In Touch",
      availableWorldwide: "Available Worldwide",
      copyright: "© 2026 DesignWithSajid | All Rights Reserved",
      privacyPolicy: "Privacy Policy",
      termsOfService: "Terms of Service",
    },
  },
  ur: {
    nav: {
      home: "ہوم",
      services: "سروسز",
      portfolio: "پورٹ فولیو",
      results: "نتائج",
      contact: "رابطہ",
      freeCall: "فری سٹریٹجی کال",
    },
    hero: {
      badge: "دنیا بھر میں 50+ برانڈز کا اعتماد",
      title: "کیا آپ کا برانڈ",
      titleHighlight: "سوشل میڈیا پر غائب ہے؟",
      subtitle: "حقیقت یہ ہے:",
      description:
        "آپ پوسٹس ڈال رہے ہیں، لیکن انگیجمنٹ زیرو ہے۔ فالورز نہیں بڑھ رہے۔ سیلز نہیں آ رہی۔ میں آپ کے برانڈ کو scroll-stopping ڈیزائنز اور سٹریٹجک کنٹینٹ سے ٹرانسفارم کرتا ہوں جو اٹینشن گریب کرتا ہے اور کسٹمرز کنورٹ کرتا ہے۔",
      cta: "فری سٹریٹجی کال بک کریں",
      ctaSecondary: "پورٹ فولیو دیکھیں",
      happyClients: "50+ خوش کلائنٹس",
      rating: "5.0 ریٹنگ",
      engagement: "انگیجمنٹ",
      engagementLabel: "اوسط اضافہ",
      projects: "پروجیکٹس",
      projectsLabel: "مکمل",
      conversion: "کنورژن",
      conversionLabel: "کلائنٹ ریٹینشن",
      turnaround: "ٹرن اراؤنڈ",
      turnaroundLabel: "ڈیلیوری ٹائم",
      brandGrowth: "میرے ساتھ کام کرنے کے بعد برانڈ گروتھ",
      rated: "#1 ریٹڈ",
      revenueImpact: "ریونیو امپیکٹ",
      monthlyGrowth: "ماہانہ گروتھ ٹرینڈ",
      thisMonth: "اس مہینے +24%",
    },
    problem: {
      badge: "کیا یہ آپ کی کہانی ہے؟",
      title: "سوشل میڈیا پر",
      titleHighlight: "سٹرگل کیوں ہو رہا ہے؟",
      description:
        "اگر آپ ان مسائل سے گزر رہے ہیں، تو آپ اکیلے نہیں ہیں۔ 90% کاروبار یہی چیلنجز فیس کرتے ہیں۔ لیکن حل ہے - اور میں آپ کو بالکل وہی دے سکتا ہوں۔",
      bottomQuestion: "کیا آپ بھی ان مسائل سے پریشان ہیں؟",
      bottomSolution: "ٹینشن مت لو - حل نیچے ہے",
      problems: [
        {
          title: "نظر نہ آنے والی پوسٹس",
          description: "آپ کی پوسٹس پہلے 3 سیکنڈز میں اٹینشن نہیں پکڑتیں - الگورتھم آپ کو نظرانداز کر دیتا ہے",
          stat: "70%",
          statLabel: "پوسٹس unseen ہوتی ہیں",
        },
        {
          title: "جنرک ڈیزائنز",
          description: "کینوا ٹیمپلیٹس سب کو ایک جیسے دکھتے ہیں - آپ کا برانڈ بھیڑ میں کھو جاتا ہے",
          stat: "89%",
          statLabel: "برانڈز ایک جیسا لک استعمال کرتے ہیں",
        },
        {
          title: "غیر مستقل برانڈنگ",
          description: "ہر پوسٹ الگ لک - کسٹمرز confused ہیں اور ٹرسٹ نہیں بنتا",
          stat: "60%",
          statLabel: "inconsistency کی وجہ سے lost trust",
        },
        {
          title: "لائکس لیکن سیلز نہیں",
          description: "انگیجمنٹ ملتی ہے لیکن انکوائریز اور سیلز نہیں - کنٹینٹ سٹریٹجی مسنگ ہے",
          stat: "95%",
          statLabel: "بغیر سٹریٹجی کنٹینٹ فیل ہوتا ہے",
        },
        {
          title: "ضائع شدہ بجٹ",
          description: "ایڈز پر پیسے لگا رہے ہیں لیکن ROI منفی ہے - ٹارگیٹنگ اور کریئیٹو دونوں کمزور ہیں",
          stat: "PKR 50K+",
          statLabel: "اوسط ماہانہ ضائع",
        },
        {
          title: "وقت کا ضیاع",
          description: "کنٹینٹ بنانے میں گھنٹے لگ جاتے ہیں لیکن نتائج زیرو - پروڈکٹیویٹی لاس",
          stat: "15+ گھنٹے",
          statLabel: "ہفتہ وار DIY کنٹینٹ پر ضائع",
        },
      ],
    },
    solution: {
      badge: "آپ کا حل یہاں ہے",
      title: "سٹریٹجک ڈیزائن + سمارٹ کنٹینٹ = گروتھ",
      description:
        "میں صرف ڈیزائنر نہیں ہوں - میں آپ کا گروتھ پارٹنر ہوں۔ ہر ڈیزائن کے پیچھے سٹریٹجی ہے، ہر پوسٹ کے پیچھے گول ہے۔ نتیجہ؟ آپ کا برانڈ ٹاپ پر۔",
      processTitle: "سادہ 4 قدمی عمل",
      processSubtitle: "صرف 4 قدموں میں confused سے confident تک",
      cta: "اپنی فری سٹریٹجی کال بک کریں",
      ctaSubtext: "کوئی commitment نہیں - صرف ویلیو",
      solutions: [
        {
          title: "Scroll-Stopping ویژولز",
          description: "ڈیزائنز جو پہلے 0.5 سیکنڈز میں اٹینشن گریب کریں - الگورتھم approved",
          benefit: "5x زیادہ reach گارنٹیڈ",
        },
        {
          title: "سٹریٹجک کنٹینٹ پلاننگ",
          description: "ہر پوسٹ ایک مقصد کے ساتھ - awareness سے conversion تک journey planned",
          benefit: "سیلز کا واضح راستہ",
        },
        {
          title: "پریمیم برانڈ آئیڈینٹٹی",
          description: "consistent اور یادگار برانڈ لک جو ٹرسٹ اور اتھارٹی بناتا ہے",
          benefit: "مقابلے سے الگ نظر آئیں",
        },
        {
          title: "سائیکالوجی بیسڈ ڈیزائن",
          description: "رنگ، فونٹس اور layouts جو سائنسی طور پر proven انگیجمنٹ بڑھاتے ہیں",
          benefit: "زیادہ کنورژن ریٹس",
        },
        {
          title: "ڈیٹا-ڈریون آپٹیمائزیشن",
          description: "پرفارمنس ٹریک کرکے کنٹینٹ continuously بہتر ہوتا ہے",
          benefit: "ماہ بہ ماہ گروتھ",
        },
        {
          title: "فاسٹ ٹرن اراؤنڈ",
          description: "48 گھنٹوں میں پروفیشنل کنٹینٹ ڈیلیوری - مزید انتظار نہیں",
          benefit: "کوئی ٹرینڈ مس نہ کریں",
        },
      ],
      process: [
        { title: "ڈسکوری کال", desc: "آپ کے برانڈ اور گولز سمجھنا" },
        { title: "سٹریٹجی پلان", desc: "کسٹم کنٹینٹ سٹریٹجی ڈویلپ کرنا" },
        { title: "ڈیزائن اور تخلیق", desc: "پریمیم کنٹینٹ بنانا" },
        { title: "لانچ اور گروتھ", desc: "نتائج ٹریک اور optimize کرنا" },
      ],
    },
    services: {
      badge: "میری سروسز",
      title: "میں آپ کے برانڈ کے لیے کیا کر سکتا ہوں",
      description:
        "میں مکمل سوشل میڈیا کنٹینٹ اور ڈیزائن سلوشنز پیش کرتا ہوں تاکہ آپ اپنے کاروبار پر فوکس کر سکیں جبکہ میں آپ کی آن لائن موجودگی سنبھالتا ہوں۔",
      benefitsTitle: "میرے ساتھ کام کرنے کے فوائد",
      benefits: [
        "مضبوط اور پروفیشنل برانڈ موجودگی",
        "زیادہ انگیجمنٹ اور reach",
        "کنٹینٹ جو صحیح audience کو اٹریکٹ کرے",
        "سوشل میڈیا سے بہتر کنورژن",
        "done-for-you کنٹینٹ سے وقت کی بچت",
        "random پوسٹنگ کی بجائے واضح سٹریٹجی",
      ],
      servicesList: [
        {
          title: "سوشل میڈیا کنٹینٹ کریئیشن",
          description:
            "پوسٹ آئیڈیاز، کنٹینٹ ڈائریکشن، اور ویژول پلاننگ جو انگیجمنٹ اور برانڈ awareness بڑھانے کے لیے ڈیزائن کی گئی ہے۔",
        },
        {
          title: "سوشل میڈیا کے لیے گرافک ڈیزائن",
          description:
            "پروفیشنل پوسٹس، carousels، سٹوریز، اور ایڈ creatives جو scroll روکتی ہیں اور آپ کی برانڈ امیج بلند کرتی ہیں۔",
        },
        {
          title: "برانڈ ویژول آئیڈینٹٹی",
          description: "consistent رنگ، typography، اور layout سٹائل تاکہ آپ کا برانڈ قابل شناخت اور قابل اعتماد ہو۔",
        },
        {
          title: "ایڈ کریئیٹو ڈیزائن",
          description:
            "high-converting creatives جو کلکس، انکوائریز، اور کیمپین پرفارمنس بہتر کرنے کے لیے ڈیزائن کی گئی ہیں۔",
        },
        {
          title: "کنٹینٹ پلاننگ سپورٹ",
          description: "structured ویژول پلاننگ تاکہ آپ کا سوشل میڈیا consistent، پروفیشنل، اور growth-focused رہے۔",
        },
      ],
    },
    footer: {
      description:
        "Scroll-stopping ویژولز اور سٹریٹجک کنٹینٹ جو attention کو انگیجمنٹ میں اور انگیجمنٹ کو results میں کنورٹ کرے۔",
      quickLinks: "فوری لنکس",
      servicesTitle: "سروسز",
      getInTouch: "رابطہ کریں",
      availableWorldwide: "دنیا بھر میں دستیاب",
      copyright: "© 2026 DesignWithSajid | تمام حقوق محفوظ ہیں",
      privacyPolicy: "پرائیویسی پالیسی",
      termsOfService: "سروس کی شرائط",
    },
  },
  ar: {
    nav: {
      home: "الرئيسية",
      services: "الخدمات",
      portfolio: "معرض الأعمال",
      results: "النتائج",
      contact: "اتصل بنا",
      freeCall: "مكالمة استراتيجية مجانية",
    },
    hero: {
      badge: "موثوق به من قبل أكثر من 50 علامة تجارية حول العالم",
      title: "هل علامتك التجارية",
      titleHighlight: "غير مرئية على وسائل التواصل؟",
      subtitle: "الحقيقة:",
      description:
        "أنت تنشر محتوى، لكن التفاعل صفر. المتابعون لا يزيدون. لا مبيعات قادمة. أحول علامتك التجارية بتصاميم مذهلة ومحتوى استراتيجي يجذب الانتباه ويحول العملاء.",
      cta: "احجز مكالمة استراتيجية مجانية",
      ctaSecondary: "عرض الأعمال",
      happyClients: "50+ عميل سعيد",
      rating: "تقييم 5.0",
      engagement: "التفاعل",
      engagementLabel: "متوسط الزيادة",
      projects: "المشاريع",
      projectsLabel: "مكتملة",
      conversion: "التحويل",
      conversionLabel: "الاحتفاظ بالعملاء",
      turnaround: "وقت التسليم",
      turnaroundLabel: "مدة التسليم",
      brandGrowth: "نمو العلامة التجارية بعد العمل معي",
      rated: "#1 تقييماً",
      revenueImpact: "تأثير الإيرادات",
      monthlyGrowth: "اتجاه النمو الشهري",
      thisMonth: "+24% هذا الشهر",
    },
    problem: {
      badge: "هل هذه قصتك؟",
      title: "لماذا تعاني على",
      titleHighlight: "وسائل التواصل الاجتماعي؟",
      description:
        "إذا كنت تواجه هذه المشاكل، فأنت لست وحدك. 90% من الشركات تواجه نفس التحديات. لكن هناك حل - ويمكنني تقديمه لك بالضبط.",
      bottomQuestion: "هل تواجه هذه المشاكل أيضاً؟",
      bottomSolution: "لا تقلق - الحل في الأسفل",
      problems: [
        {
          title: "منشورات غير مرئية",
          description: "منشوراتك لا تجذب الانتباه في أول 3 ثوانٍ - الخوارزمية تتجاهلك",
          stat: "70%",
          statLabel: "من المنشورات لا تُرى",
        },
        {
          title: "تصاميم عامة",
          description: "قوالب Canva كلها تبدو متشابهة - علامتك التجارية تضيع في الزحام",
          stat: "89%",
          statLabel: "من العلامات تستخدم نفس المظهر",
        },
        {
          title: "هوية غير متسقة",
          description: "كل منشور يبدو مختلفاً - العملاء محتارون والثقة لا تُبنى",
          stat: "60%",
          statLabel: "فقدان الثقة بسبب عدم الاتساق",
        },
        {
          title: "إعجابات بدون مبيعات",
          description: "تحصل على تفاعل لكن لا استفسارات أو مبيعات - استراتيجية المحتوى مفقودة",
          stat: "95%",
          statLabel: "المحتوى بدون استراتيجية يفشل",
        },
        {
          title: "ميزانية مهدرة",
          description: "تنفق على الإعلانات لكن العائد سلبي - الاستهداف والإبداع كلاهما ضعيف",
          stat: "$500+",
          statLabel: "مهدرة شهرياً في المتوسط",
        },
        {
          title: "استنزاف الوقت",
          description: "ساعات تُقضى في إنشاء المحتوى لكن النتائج صفر - فقدان الإنتاجية",
          stat: "15+ ساعة",
          statLabel: "أسبوعياً مهدرة على المحتوى الذاتي",
        },
      ],
    },
    solution: {
      badge: "حلك هنا",
      title: "تصميم استراتيجي + محتوى ذكي = نمو",
      description:
        "لست مجرد مصمم - أنا شريكك في النمو. كل تصميم وراءه استراتيجية، كل منشور له هدف. النتيجة؟ علامتك التجارية في القمة.",
      processTitle: "عملية من 4 خطوات بسيطة",
      processSubtitle: "من الحيرة إلى الثقة في 4 خطوات فقط",
      cta: "احجز مكالمتك الاستراتيجية المجانية",
      ctaSubtext: "بدون التزام - قيمة فقط",
      solutions: [
        {
          title: "مرئيات توقف التمرير",
          description: "تصاميم تجذب الانتباه في أول 0.5 ثانية - معتمدة من الخوارزمية",
          benefit: "5x وصول مضمون أكثر",
        },
        {
          title: "تخطيط محتوى استراتيجي",
          description: "كل منشور بهدف - رحلة مخططة من الوعي إلى التحويل",
          benefit: "مسار واضح للمبيعات",
        },
        {
          title: "هوية علامة تجارية متميزة",
          description: "مظهر علامة تجارية متسق لا يُنسى يبني الثقة والسلطة",
          benefit: "تميز عن المنافسة",
        },
        {
          title: "تصميم قائم على علم النفس",
          description: "ألوان وخطوط وتخطيطات مثبتة علمياً لتعزيز التفاعل",
          benefit: "معدلات تحويل أعلى",
        },
        { title: "تحسين مدفوع بالبيانات", description: "تتبع الأداء وتحسين المحتوى باستمرار", benefit: "نمو شهري" },
        {
          title: "تسليم سريع",
          description: "تسليم محتوى احترافي في 48 ساعة - لا مزيد من الانتظار",
          benefit: "لا تفوت أي اتجاه",
        },
      ],
      process: [
        { title: "مكالمة الاكتشاف", desc: "فهم علامتك التجارية وأهدافك" },
        { title: "خطة الاستراتيجية", desc: "تطوير استراتيجية محتوى مخصصة" },
        { title: "التصميم والإنشاء", desc: "إنشاء محتوى متميز" },
        { title: "الإطلاق والنمو", desc: "تتبع وتحسين النتائج" },
      ],
    },
    services: {
      badge: "خدماتي",
      title: "ما يمكنني فعله لعلامتك التجارية",
      description:
        "أقدم حلول محتوى وتصميم كاملة لوسائل التواصل الاجتماعي حتى تتمكن من التركيز على عملك بينما أتولى حضورك الرقمي.",
      benefitsTitle: "ما ستكسبه من العمل معي",
      benefits: [
        "حضور علامة تجارية قوي واحترافي",
        "تفاعل ووصول أعلى",
        "محتوى يجذب الجمهور المناسب",
        "تحويل أفضل من وسائل التواصل",
        "توفير الوقت مع محتوى جاهز",
        "استراتيجية واضحة بدلاً من النشر العشوائي",
      ],
      servicesList: [
        {
          title: "إنشاء محتوى وسائل التواصل",
          description: "أفكار المنشورات وتوجيه المحتوى والتخطيط البصري المصمم لزيادة التفاعل والوعي بالعلامة التجارية.",
        },
        {
          title: "تصميم جرافيك لوسائل التواصل",
          description: "منشورات احترافية وكاروسيل وقصص وإعلانات إبداعية توقف التمرير وترفع صورة علامتك التجارية.",
        },
        {
          title: "هوية بصرية للعلامة التجارية",
          description: "ألوان وخطوط وأسلوب تخطيط متسق لجعل علامتك التجارية معروفة وموثوقة.",
        },
        {
          title: "تصميم إعلانات إبداعية",
          description: "إبداعات عالية التحويل مصممة لتحسين النقرات والاستفسارات وأداء الحملات.",
        },
        { title: "دعم تخطيط المحتوى", description: "تخطيط بصري منظم ليبقى محتواك متسقاً واحترافياً ومركزاً على النمو." },
      ],
    },
    footer: {
      description: "مرئيات توقف التمرير ومحتوى استراتيجي يحول الانتباه إلى تفاعل والتفاعل إلى نتائج.",
      quickLinks: "روابط سريعة",
      servicesTitle: "الخدمات",
      getInTouch: "تواصل معنا",
      availableWorldwide: "متاح حول العالم",
      copyright: "© 2026 DesignWithSajid | جميع الحقوق محفوظة",
      privacyPolicy: "سياسة الخصوصية",
      termsOfService: "شروط الخدمة",
    },
  },
  es: {
    nav: {
      home: "Inicio",
      services: "Servicios",
      portfolio: "Portafolio",
      results: "Resultados",
      contact: "Contacto",
      freeCall: "Llamada Estratégica Gratis",
    },
    hero: {
      badge: "Confianza de más de 50 marcas en todo el mundo",
      title: "¿Tu Marca es",
      titleHighlight: "Invisible en Redes Sociales?",
      subtitle: "Realidad:",
      description:
        "Estás publicando contenido, pero el engagement es cero. Los seguidores no crecen. No llegan ventas. Transformo tu marca con diseños que detienen el scroll y contenido estratégico que capta atención y convierte clientes.",
      cta: "Reserva tu Llamada Estratégica Gratis",
      ctaSecondary: "Ver Portafolio",
      happyClients: "50+ Clientes Felices",
      rating: "Calificación 5.0",
      engagement: "Engagement",
      engagementLabel: "Aumento Promedio",
      projects: "Proyectos",
      projectsLabel: "Completados",
      conversion: "Conversión",
      conversionLabel: "Retención de Clientes",
      turnaround: "Entrega",
      turnaroundLabel: "Tiempo de Entrega",
      brandGrowth: "Crecimiento de Marca Después de Trabajar Conmigo",
      rated: "#1 Calificado",
      revenueImpact: "Impacto en Ingresos",
      monthlyGrowth: "Tendencia de Crecimiento Mensual",
      thisMonth: "+24% este mes",
    },
    problem: {
      badge: "¿Es Esta Tu Historia?",
      title: "¿Por Qué Estás",
      titleHighlight: "Luchando en Redes Sociales?",
      description:
        "Si enfrentas estos problemas, no estás solo. El 90% de los negocios enfrentan los mismos desafíos. Pero hay una solución - y puedo darte exactamente eso.",
      bottomQuestion: "¿También enfrentas estos problemas?",
      bottomSolution: "No te preocupes - la solución está abajo",
      problems: [
        {
          title: "Publicaciones Invisibles",
          description: "Tus publicaciones no captan atención en los primeros 3 segundos - el algoritmo te ignora",
          stat: "70%",
          statLabel: "publicaciones no se ven",
        },
        {
          title: "Diseños Genéricos",
          description: "Las plantillas de Canva todas lucen igual - tu marca se pierde en la multitud",
          stat: "89%",
          statLabel: "marcas usan el mismo look",
        },
        {
          title: "Branding Inconsistente",
          description: "Cada publicación luce diferente - los clientes están confundidos y no se construye confianza",
          stat: "60%",
          statLabel: "pérdida de confianza por inconsistencia",
        },
        {
          title: "Likes Pero Sin Ventas",
          description: "Obtienes engagement pero no consultas ni ventas - falta estrategia de contenido",
          stat: "95%",
          statLabel: "contenido sin estrategia falla",
        },
        {
          title: "Presupuesto Desperdiciado",
          description: "Gastas en anuncios pero el ROI es negativo - segmentación y creatividad ambas débiles",
          stat: "$500+",
          statLabel: "desperdiciado mensualmente en promedio",
        },
        {
          title: "Pérdida de Tiempo",
          description: "Horas en crear contenido pero resultados cero - pérdida de productividad",
          stat: "15+ hrs",
          statLabel: "semanales desperdiciadas en contenido DIY",
        },
      ],
    },
    solution: {
      badge: "Tu Solución Está Aquí",
      title: "Diseño Estratégico + Contenido Inteligente = Crecimiento",
      description:
        "No soy solo un diseñador - soy tu socio de crecimiento. Cada diseño tiene estrategia detrás, cada publicación tiene un objetivo. ¿Resultado? Tu marca en la cima.",
      processTitle: "Proceso Simple de 4 Pasos",
      processSubtitle: "De confundido a confiado en solo 4 pasos",
      cta: "Reserva tu Llamada Estratégica Gratis",
      ctaSubtext: "Sin compromiso - solo valor",
      solutions: [
        {
          title: "Visuales que Detienen el Scroll",
          description: "Diseños que captan atención en los primeros 0.5 segundos - aprobados por el algoritmo",
          benefit: "5x más alcance garantizado",
        },
        {
          title: "Planificación Estratégica de Contenido",
          description: "Cada publicación con propósito - viaje planificado desde awareness hasta conversión",
          benefit: "Camino claro a ventas",
        },
        {
          title: "Identidad de Marca Premium",
          description: "Look de marca consistente y memorable que construye confianza y autoridad",
          benefit: "Destaca de la competencia",
        },
        {
          title: "Diseño Basado en Psicología",
          description: "Colores, fuentes y layouts científicamente probados para aumentar engagement",
          benefit: "Mayores tasas de conversión",
        },
        {
          title: "Optimización Basada en Datos",
          description: "Seguimiento de rendimiento y mejora continua del contenido",
          benefit: "Crecimiento mes a mes",
        },
        {
          title: "Entrega Rápida",
          description: "Entrega de contenido profesional en 48 horas - sin más esperas",
          benefit: "Nunca pierdas una tendencia",
        },
      ],
      process: [
        { title: "Llamada de Descubrimiento", desc: "Entender tu marca y objetivos" },
        { title: "Plan de Estrategia", desc: "Desarrollar estrategia de contenido personalizada" },
        { title: "Diseñar y Crear", desc: "Crear contenido premium" },
        { title: "Lanzar y Crecer", desc: "Seguimiento y optimización de resultados" },
      ],
    },
    services: {
      badge: "Mis Servicios",
      title: "Lo Que Puedo Hacer Por Tu Marca",
      description:
        "Ofrezco soluciones completas de contenido y diseño para redes sociales para que puedas enfocarte en tu negocio mientras yo manejo tu presencia online.",
      benefitsTitle: "Lo Que Ganas Trabajando Conmigo",
      benefits: [
        "Presencia de marca fuerte y profesional",
        "Mayor engagement y alcance",
        "Contenido que atrae a la audiencia correcta",
        "Mejor conversión desde redes sociales",
        "Tiempo ahorrado con contenido hecho para ti",
        "Estrategia clara en lugar de publicaciones aleatorias",
      ],
      servicesList: [
        {
          title: "Creación de Contenido para Redes",
          description:
            "Ideas de publicaciones, dirección de contenido y planificación visual diseñada para aumentar engagement y awareness de marca.",
        },
        {
          title: "Diseño Gráfico para Redes Sociales",
          description:
            "Publicaciones profesionales, carruseles, historias y creatividades publicitarias que detienen el scroll y elevan tu imagen de marca.",
        },
        {
          title: "Identidad Visual de Marca",
          description:
            "Colores consistentes, tipografía y estilo de diseño para hacer tu marca reconocible y confiable.",
        },
        {
          title: "Diseño de Creatividades Publicitarias",
          description:
            "Creatividades de alta conversión diseñadas para mejorar clics, consultas y rendimiento de campañas.",
        },
        {
          title: "Soporte de Planificación de Contenido",
          description:
            "Planificación visual estructurada para que tu contenido se mantenga consistente, profesional y enfocado en crecimiento.",
        },
      ],
    },
    footer: {
      description:
        "Visuales que detienen el scroll y contenido estratégico que convierte atención en engagement y engagement en resultados.",
      quickLinks: "Enlaces Rápidos",
      servicesTitle: "Servicios",
      getInTouch: "Contáctanos",
      availableWorldwide: "Disponible Mundialmente",
      copyright: "© 2026 DesignWithSajid | Todos los Derechos Reservados",
      privacyPolicy: "Política de Privacidad",
      termsOfService: "Términos de Servicio",
    },
  },
  fr: {
    nav: {
      home: "Accueil",
      services: "Services",
      portfolio: "Portfolio",
      results: "Résultats",
      contact: "Contact",
      freeCall: "Appel Stratégique Gratuit",
    },
    hero: {
      badge: "Confiance de plus de 50 marques dans le monde",
      title: "Votre Marque est-elle",
      titleHighlight: "Invisible sur les Réseaux Sociaux?",
      subtitle: "Réalité:",
      description:
        "Vous publiez du contenu, mais l'engagement est nul. Les abonnés ne croissent pas. Pas de ventes. Je transforme votre marque avec des designs qui arrêtent le scroll et du contenu stratégique qui capte l'attention et convertit les clients.",
      cta: "Réservez votre Appel Stratégique Gratuit",
      ctaSecondary: "Voir le Portfolio",
      happyClients: "50+ Clients Satisfaits",
      rating: "Note 5.0",
      engagement: "Engagement",
      engagementLabel: "Augmentation Moyenne",
      projects: "Projets",
      projectsLabel: "Terminés",
      conversion: "Conversion",
      conversionLabel: "Rétention Client",
      turnaround: "Livraison",
      turnaroundLabel: "Délai de Livraison",
      brandGrowth: "Croissance de Marque Après Avoir Travaillé Avec Moi",
      rated: "#1 Noté",
      revenueImpact: "Impact sur les Revenus",
      monthlyGrowth: "Tendance de Croissance Mensuelle",
      thisMonth: "+24% ce mois",
    },
    problem: {
      badge: "Est-ce Votre Histoire?",
      title: "Pourquoi Luttez-vous sur les",
      titleHighlight: "Réseaux Sociaux?",
      description:
        "Si vous faites face à ces problèmes, vous n'êtes pas seul. 90% des entreprises font face aux mêmes défis. Mais il y a une solution - et je peux vous la donner exactement.",
      bottomQuestion: "Vous faites face à ces problèmes aussi?",
      bottomSolution: "Ne vous inquiétez pas - la solution est ci-dessous",
      problems: [
        {
          title: "Publications Invisibles",
          description:
            "Vos publications ne captent pas l'attention dans les 3 premières secondes - l'algorithme vous ignore",
          stat: "70%",
          statLabel: "des publications ne sont pas vues",
        },
        {
          title: "Designs Génériques",
          description: "Les templates Canva se ressemblent tous - votre marque se perd dans la foule",
          stat: "89%",
          statLabel: "des marques utilisent le même look",
        },
        {
          title: "Branding Incohérent",
          description:
            "Chaque publication a un look différent - les clients sont confus et la confiance ne se construit pas",
          stat: "60%",
          statLabel: "perte de confiance due à l'incohérence",
        },
        {
          title: "Likes Mais Pas de Ventes",
          description: "Vous obtenez de l'engagement mais pas de demandes ou ventes - stratégie de contenu manquante",
          stat: "95%",
          statLabel: "du contenu sans stratégie échoue",
        },
        {
          title: "Budget Gaspillé",
          description: "Vous dépensez en publicités mais le ROI est négatif - ciblage et créativité tous deux faibles",
          stat: "500€+",
          statLabel: "gaspillé mensuellement en moyenne",
        },
        {
          title: "Perte de Temps",
          description: "Des heures passées à créer du contenu mais résultats nuls - perte de productivité",
          stat: "15+ hrs",
          statLabel: "par semaine gaspillées sur le contenu DIY",
        },
      ],
    },
    solution: {
      badge: "Votre Solution Est Ici",
      title: "Design Stratégique + Contenu Intelligent = Croissance",
      description:
        "Je ne suis pas qu'un designer - je suis votre partenaire de croissance. Chaque design a une stratégie derrière, chaque publication a un objectif. Résultat? Votre marque au sommet.",
      processTitle: "Processus Simple en 4 Étapes",
      processSubtitle: "De confus à confiant en seulement 4 étapes",
      cta: "Réservez votre Appel Stratégique Gratuit",
      ctaSubtext: "Sans engagement - juste de la valeur",
      solutions: [
        {
          title: "Visuels qui Arrêtent le Scroll",
          description: "Des designs qui captent l'attention en 0.5 seconde - approuvés par l'algorithme",
          benefit: "5x plus de portée garantie",
        },
        {
          title: "Planification Stratégique de Contenu",
          description: "Chaque publication avec un objectif - parcours planifié de la sensibilisation à la conversion",
          benefit: "Chemin clair vers les ventes",
        },
        {
          title: "Identité de Marque Premium",
          description: "Look de marque cohérent et mémorable qui construit confiance et autorité",
          benefit: "Démarquez-vous de la concurrence",
        },
        {
          title: "Design Basé sur la Psychologie",
          description: "Couleurs, polices et mises en page scientifiquement prouvées pour booster l'engagement",
          benefit: "Taux de conversion plus élevés",
        },
        {
          title: "Optimisation Basée sur les Données",
          description: "Suivre les performances et améliorer continuellement le contenu",
          benefit: "Croissance mois après mois",
        },
        {
          title: "Livraison Rapide",
          description: "Livraison de contenu professionnel en 48 heures - plus d'attente",
          benefit: "Ne manquez jamais une tendance",
        },
      ],
      process: [
        { title: "Appel Découverte", desc: "Comprendre votre marque et vos objectifs" },
        { title: "Plan Stratégique", desc: "Développer une stratégie de contenu personnalisée" },
        { title: "Concevoir et Créer", desc: "Créer du contenu premium" },
        { title: "Lancer et Croître", desc: "Suivre et optimiser les résultats" },
      ],
    },
    services: {
      badge: "Mes Services",
      title: "Ce Que Je Peux Faire Pour Votre Marque",
      description:
        "J'offre des solutions complètes de contenu et design pour les réseaux sociaux pour que vous puissiez vous concentrer sur votre entreprise pendant que je gère votre présence en ligne.",
      benefitsTitle: "Ce Que Vous Gagnez en Travaillant Avec Moi",
      benefits: [
        "Présence de marque forte et professionnelle",
        "Engagement et portée plus élevés",
        "Contenu qui attire la bonne audience",
        "Meilleure conversion depuis les réseaux sociaux",
        "Temps économisé avec du contenu fait pour vous",
        "Stratégie claire au lieu de publications aléatoires",
      ],
      servicesList: [
        {
          title: "Création de Contenu Réseaux Sociaux",
          description:
            "Idées de publications, direction de contenu et planification visuelle conçues pour augmenter l'engagement et la notoriété de marque.",
        },
        {
          title: "Design Graphique pour Réseaux Sociaux",
          description:
            "Publications professionnelles, carrousels, stories et créatifs publicitaires qui arrêtent le scroll et élèvent votre image de marque.",
        },
        {
          title: "Identité Visuelle de Marque",
          description:
            "Couleurs cohérentes, typographie et style de mise en page pour rendre votre marque reconnaissable et digne de confiance.",
        },
        {
          title: "Design de Créatifs Publicitaires",
          description:
            "Créatifs à haute conversion conçus pour améliorer les clics, les demandes et les performances des campagnes.",
        },
        {
          title: "Support de Planification de Contenu",
          description:
            "Planification visuelle structurée pour que vos réseaux sociaux restent cohérents, professionnels et axés sur la croissance.",
        },
      ],
    },
    footer: {
      description:
        "Visuels qui arrêtent le scroll et contenu stratégique qui convertit l'attention en engagement et l'engagement en résultats.",
      quickLinks: "Liens Rapides",
      servicesTitle: "Services",
      getInTouch: "Contactez-nous",
      availableWorldwide: "Disponible Mondialement",
      copyright: "© 2026 DesignWithSajid | Tous Droits Réservés",
      privacyPolicy: "Politique de Confidentialité",
      termsOfService: "Conditions d'Utilisation",
    },
  },
  de: {
    nav: {
      home: "Startseite",
      services: "Dienstleistungen",
      portfolio: "Portfolio",
      results: "Ergebnisse",
      contact: "Kontakt",
      freeCall: "Kostenloser Strategieanruf",
    },
    hero: {
      badge: "Vertrauen von über 50 Marken weltweit",
      title: "Ist Ihre Marke",
      titleHighlight: "Unsichtbar in Social Media?",
      subtitle: "Realitätscheck:",
      description:
        "Sie posten Inhalte, aber das Engagement ist null. Follower wachsen nicht. Keine Verkäufe. Ich transformiere Ihre Marke mit scroll-stoppenden Designs und strategischem Content, der Aufmerksamkeit erregt und Kunden konvertiert.",
      cta: "Kostenlosen Strategieanruf Buchen",
      ctaSecondary: "Portfolio Ansehen",
      happyClients: "50+ Zufriedene Kunden",
      rating: "5.0 Bewertung",
      engagement: "Engagement",
      engagementLabel: "Durchschnittliche Steigerung",
      projects: "Projekte",
      projectsLabel: "Abgeschlossen",
      conversion: "Konversion",
      conversionLabel: "Kundenbindung",
      turnaround: "Lieferzeit",
      turnaroundLabel: "Lieferzeit",
      brandGrowth: "Markenwachstum Nach Der Zusammenarbeit Mit Mir",
      rated: "#1 Bewertet",
      revenueImpact: "Umsatzwirkung",
      monthlyGrowth: "Monatlicher Wachstumstrend",
      thisMonth: "+24% diesen Monat",
    },
    problem: {
      badge: "Ist Das Ihre Geschichte?",
      title: "Warum Kämpfen Sie in",
      titleHighlight: "Social Media?",
      description:
        "Wenn Sie diese Probleme haben, sind Sie nicht allein. 90% der Unternehmen stehen vor denselben Herausforderungen. Aber es gibt eine Lösung - und ich kann sie Ihnen genau geben.",
      bottomQuestion: "Haben Sie auch diese Probleme?",
      bottomSolution: "Keine Sorge - die Lösung ist unten",
      problems: [
        {
          title: "Unsichtbare Posts",
          description:
            "Ihre Posts erregen in den ersten 3 Sekunden keine Aufmerksamkeit - der Algorithmus ignoriert Sie",
          stat: "70%",
          statLabel: "der Posts werden nicht gesehen",
        },
        {
          title: "Generische Designs",
          description: "Canva-Templates sehen alle gleich aus - Ihre Marke geht in der Menge unter",
          stat: "89%",
          statLabel: "der Marken nutzen den gleichen Look",
        },
        {
          title: "Inkonsistentes Branding",
          description: "Jeder Post sieht anders aus - Kunden sind verwirrt und Vertrauen baut sich nicht auf",
          stat: "60%",
          statLabel: "Vertrauensverlust durch Inkonsistenz",
        },
        {
          title: "Likes Aber Keine Verkäufe",
          description: "Sie bekommen Engagement aber keine Anfragen oder Verkäufe - Content-Strategie fehlt",
          stat: "95%",
          statLabel: "Content ohne Strategie scheitert",
        },
        {
          title: "Verschwendetes Budget",
          description: "Sie geben für Anzeigen aus aber der ROI ist negativ - Targeting und Kreativ beide schwach",
          stat: "500€+",
          statLabel: "monatlich verschwendet im Durchschnitt",
        },
        {
          title: "Zeitverschwendung",
          description: "Stunden für Content-Erstellung aber null Ergebnisse - Produktivitätsverlust",
          stat: "15+ Std",
          statLabel: "wöchentlich für DIY-Content verschwendet",
        },
      ],
    },
    solution: {
      badge: "Ihre Lösung Ist Hier",
      title: "Strategisches Design + Smarter Content = Wachstum",
      description:
        "Ich bin nicht nur Designer - ich bin Ihr Wachstumspartner. Jedes Design hat eine Strategie dahinter, jeder Post hat ein Ziel. Ergebnis? Ihre Marke an der Spitze.",
      processTitle: "Einfacher 4-Schritte-Prozess",
      processSubtitle: "Von verwirrt zu selbstbewusst in nur 4 Schritten",
      cta: "Buchen Sie Ihren Kostenlosen Strategieanruf",
      ctaSubtext: "Keine Verpflichtung - nur Wert",
      solutions: [
        {
          title: "Scroll-Stoppende Visuals",
          description: "Designs, die in 0,5 Sekunden Aufmerksamkeit erregen - algorithmusgeprüft",
          benefit: "5x mehr Reichweite garantiert",
        },
        {
          title: "Strategische Content-Planung",
          description: "Jeder Post mit Zweck - Reise von Awareness bis Conversion geplant",
          benefit: "Klarer Weg zu Verkäufen",
        },
        {
          title: "Premium Markenidentität",
          description: "Konsistenter und einprägsamer Markenlook, der Vertrauen und Autorität aufbaut",
          benefit: "Von der Konkurrenz abheben",
        },
        {
          title: "Psychologiebasiertes Design",
          description: "Farben, Schriften und Layouts wissenschaftlich bewiesen für mehr Engagement",
          benefit: "Höhere Konversionsraten",
        },
        {
          title: "Datengetriebene Optimierung",
          description: "Performance verfolgen und Content kontinuierlich verbessern",
          benefit: "Monatliches Wachstum",
        },
        {
          title: "Schnelle Lieferung",
          description: "Professionelle Content-Lieferung in 48 Stunden - kein Warten mehr",
          benefit: "Verpassen Sie keinen Trend",
        },
      ],
      process: [
        { title: "Entdeckungsgespräch", desc: "Ihre Marke und Ziele verstehen" },
        { title: "Strategieplan", desc: "Individuelle Content-Strategie entwickeln" },
        { title: "Design & Erstellen", desc: "Premium Content erstellen" },
        { title: "Starten & Wachsen", desc: "Ergebnisse verfolgen und optimieren" },
      ],
    },
    services: {
      badge: "Meine Dienstleistungen",
      title: "Was Ich Für Ihre Marke Tun Kann",
      description:
        "Ich biete komplette Social Media Content- und Designlösungen, damit Sie sich auf Ihr Geschäft konzentrieren können, während ich Ihre Online-Präsenz betreue.",
      benefitsTitle: "Was Sie Durch Die Zusammenarbeit Mit Mir Gewinnen",
      benefits: [
        "Starke und professionelle Markenpräsenz",
        "Höheres Engagement und Reichweite",
        "Content, der die richtige Zielgruppe anzieht",
        "Bessere Konversion von Social Media",
        "Zeitersparnis mit fertigem Content",
        "Klare Strategie statt zufälligem Posten",
      ],
      servicesList: [
        {
          title: "Social Media Content-Erstellung",
          description: "Post-Ideen, Content-Richtung und visuelle Planung für mehr Engagement und Markenbekanntheit.",
        },
        {
          title: "Grafikdesign für Social Media",
          description:
            "Professionelle Posts, Karussells, Stories und Werbeanzeigen, die den Scroll stoppen und Ihr Markenimage erhöhen.",
        },
        {
          title: "Visuelle Markenidentität",
          description:
            "Konsistente Farben, Typografie und Layoutstil, um Ihre Marke erkennbar und vertrauenswürdig zu machen.",
        },
        {
          title: "Werbekreativ-Design",
          description: "Hochkonvertierende Kreative für mehr Klicks, Anfragen und Kampagnenleistung.",
        },
        {
          title: "Content-Planungsunterstützung",
          description:
            "Strukturierte visuelle Planung, damit Ihre Social Media konsistent, professionell und wachstumsorientiert bleibt.",
        },
      ],
    },
    footer: {
      description:
        "Scroll-stoppende Visuals und strategischer Content, der Aufmerksamkeit in Engagement und Engagement in Ergebnisse umwandelt.",
      quickLinks: "Schnelllinks",
      servicesTitle: "Dienstleistungen",
      getInTouch: "Kontaktieren Sie Uns",
      availableWorldwide: "Weltweit Verfügbar",
      copyright: "© 2026 DesignWithSajid | Alle Rechte Vorbehalten",
      privacyPolicy: "Datenschutz",
      termsOfService: "Nutzungsbedingungen",
    },
  },
  hi: {
    nav: {
      home: "होम",
      services: "सेवाएं",
      portfolio: "पोर्टफोलियो",
      results: "परिणाम",
      contact: "संपर्क",
      freeCall: "फ्री स्ट्रैटेजी कॉल",
    },
    hero: {
      badge: "दुनिया भर में 50+ ब्रांड्स का भरोसा",
      title: "क्या आपका ब्रांड",
      titleHighlight: "सोशल मीडिया पर इनविज़िबल है?",
      subtitle: "हकीकत:",
      description:
        "आप पोस्ट डाल रहे हैं, लेकिन एंगेजमेंट ज़ीरो है। फॉलोअर्स नहीं बढ़ रहे। सेल्स नहीं आ रही। मैं आपके ब्रांड को scroll-stopping डिज़ाइन्स और स्ट्रैटेजिक कंटेंट से ट्रांसफॉर्म करता हूं जो अटेंशन ग्रैब करता है और कस्टमर्स कन्वर्ट करता है।",
      cta: "फ्री स्ट्रैटेजी कॉल बुक करें",
      ctaSecondary: "पोर्टफोलियो देखें",
      happyClients: "50+ खुश क्लाइंट्स",
      rating: "5.0 रेटिंग",
      engagement: "एंगेजमेंट",
      engagementLabel: "औसत बढ़ोतरी",
      projects: "प्रोजेक्ट्स",
      projectsLabel: "पूरे हुए",
      conversion: "कन्वर्शन",
      conversionLabel: "क्लाइंट रिटेंशन",
      turnaround: "टर्नअराउंड",
      turnaroundLabel: "डिलीवरी टाइम",
      brandGrowth: "मेरे साथ काम करने के बाद ब्रांड ग्रोथ",
      rated: "#1 रेटेड",
      revenueImpact: "रेवेन्यू इम्पैक्ट",
      monthlyGrowth: "मासिक ग्रोथ ट्रेंड",
      thisMonth: "इस महीने +24%",
    },
    problem: {
      badge: "क्या यह आपकी कहानी है?",
      title: "सोशल मीडिया पर",
      titleHighlight: "स्ट्रगल क्यों हो रहा है?",
      description:
        "अगर आप इन समस्याओं से गुज़र रहे हैं, तो आप अकेले नहीं हैं। 90% बिज़नेस यही चैलेंजेस फेस करते हैं। लेकिन सॉल्यूशन है - और मैं आपको बिल्कुल वही दे सकता हूं।",
      bottomQuestion: "क्या आप भी इन समस्याओं से परेशान हैं?",
      bottomSolution: "टेंशन मत लो - सॉल्यूशन नीचे है",
      problems: [
        {
          title: "इनविज़िबल पोस्ट्स",
          description: "आपकी पोस्ट्स पहले 3 सेकंड में अटेंशन नहीं पकड़तीं - एल्गोरिथम आपको इग्नोर कर देता है",
          stat: "70%",
          statLabel: "पोस्ट्स unseen होती हैं",
        },
        {
          title: "जेनेरिक डिज़ाइन्स",
          description: "Canva टेम्प्लेट्स सबको एक जैसे दिखते हैं - आपका ब्रांड भीड़ में खो जाता है",
          stat: "89%",
          statLabel: "ब्रांड्स एक जैसा लुक यूज़ करते हैं",
        },
        {
          title: "इनकंसिस्टेंट ब्रांडिंग",
          description: "हर पोस्ट अलग लुक - कस्टमर्स confused हैं और ट्रस्ट नहीं बनता",
          stat: "60%",
          statLabel: "inconsistency से lost trust",
        },
        {
          title: "लाइक्स लेकिन सेल्स नहीं",
          description: "एंगेजमेंट मिलती है लेकिन इंक्वायरीज़ और सेल्स नहीं - कंटेंट स्ट्रैटेजी मिसिंग है",
          stat: "95%",
          statLabel: "बिना स्ट्रैटेजी कंटेंट फेल होता है",
        },
        {
          title: "वेस्टेड बजट",
          description: "एड्स पर पैसे लगा रहे हैं लेकिन ROI नेगेटिव है - टारगेटिंग और क्रिएटिव दोनों weak हैं",
          stat: "₹40K+",
          statLabel: "औसत मासिक वेस्ट",
        },
        {
          title: "टाइम ड्रेन",
          description: "कंटेंट बनाने में घंटे लग जाते हैं लेकिन रिज़ल्ट्स ज़ीरो - प्रोडक्टिविटी लॉस",
          stat: "15+ घंटे",
          statLabel: "हफ्ते में DIY कंटेंट पर वेस्ट",
        },
      ],
    },
    solution: {
      badge: "आपका सॉल्यूशन यहां है",
      title: "स्ट्रैटेजिक डिज़ाइन + स्मार्ट कंटेंट = ग्रोथ",
      description:
        "मैं सिर्फ डिज़ाइनर नहीं हूं - मैं आपका ग्रोथ पार्टनर हूं। हर डिज़ाइन के पीछे स्ट्रैटेजी है, हर पोस्ट के पीछे गोल है। रिज़ल्ट? आपका ब्रांड टॉप पर।",
      processTitle: "सिंपल 4-स्टेप प्रोसेस",
      processSubtitle: "सिर्फ 4 स्टेप्स में confused से confident तक",
      cta: "अपनी फ्री स्ट्रैटेजी कॉल बुक करें",
      ctaSubtext: "कोई commitment नहीं - सिर्फ वैल्यू",
      solutions: [
        {
          title: "Scroll-Stopping विज़ुअल्स",
          description: "डिज़ाइन्स जो पहले 0.5 सेकंड में अटेंशन ग्रैब करें - एल्गोरिथम approved",
          benefit: "5x ज़्यादा reach गारंटीड",
        },
        {
          title: "स्ट्रैटेजिक कंटेंट प्लानिंग",
          description: "हर पोस्ट एक purpose के साथ - awareness से conversion तक journey planned",
          benefit: "सेल्स का क्लियर पाथ",
        },
        {
          title: "प्रीमियम ब्रांड आइडेंटिटी",
          description: "consistent और मेमोरेबल ब्रांड लुक जो ट्रस्ट और अथॉरिटी बनाए",
          benefit: "कॉम्पिटिशन से अलग दिखें",
        },
        {
          title: "साइकोलॉजी बेस्ड डिज़ाइन",
          description: "कलर्स, फॉन्ट्स और layouts जो साइंटिफिकली proven एंगेजमेंट बढ़ाते हैं",
          benefit: "हायर कन्वर्शन रेट्स",
        },
        {
          title: "डेटा-ड्रिवन ऑप्टिमाइज़ेशन",
          description: "परफॉर्मेंस ट्रैक करके कंटेंट continuously इम्प्रूव होता है",
          benefit: "महीने दर महीने ग्रोथ",
        },
        {
          title: "फास्ट टर्नअराउंड",
          description: "48 घंटों में प्रोफेशनल कंटेंट डिलीवरी - और इंतज़ार नहीं",
          benefit: "कोई ट्रेंड मिस न करें",
        },
      ],
      process: [
        { title: "डिस्कवरी कॉल", desc: "आपके ब्रांड और गोल्स समझना" },
        { title: "स्ट्रैटेजी प्लान", desc: "कस्टम कंटेंट स्ट्रैटेजी डेवलप करना" },
        { title: "डिज़ाइन और क्रिएट", desc: "प्रीमियम कंटेंट बनाना" },
        { title: "लॉन्च और ग्रो", desc: "रिज़ल्ट्स ट्रैक और optimize करना" },
      ],
    },
    services: {
      badge: "मेरी सेवाएं",
      title: "मैं आपके ब्रांड के लिए क्या कर सकता हूं",
      description:
        "मैं पूरा सोशल मीडिया कंटेंट और डिज़ाइन सॉल्यूशन देता हूं ताकि आप अपने बिज़नेस पर फोकस कर सकें जबकि मैं आपकी ऑनलाइन प्रेज़ेंस संभालता हूं।",
      benefitsTitle: "मेरे साथ काम करने के फायदे",
      benefits: [
        "मज़बूत और प्रोफेशनल ब्रांड प्रेज़ेंस",
        "ज़्यादा एंगेजमेंट और reach",
        "कंटेंट जो सही audience को अट्रैक्ट करे",
        "सोशल मीडिया से बेहतर कन्वर्शन",
        "done-for-you कंटेंट से टाइम बचत",
        "random पोस्टिंग की जगह क्लियर स्ट्रैटेजी",
      ],
      servicesList: [
        {
          title: "सोशल मीडिया कंटेंट क्रिएशन",
          description:
            "पोस्ट आइडियाज़, कंटेंट डायरेक्शन, और विज़ुअल प्लानिंग जो एंगेजमेंट और ब्रांड awareness बढ़ाने के लिए डिज़ाइन की गई है।",
        },
        {
          title: "सोशल मीडिया के लिए ग्राफिक डिज़ाइन",
          description: "प्रोफेशनल पोस्ट्स, carousels, स्टोरीज़, और एड creatives जो scroll रोकती हैं और आपकी ब्रांड इमेज बढ़ाती हैं।",
        },
        {
          title: "ब्रांड विज़ुअल आइडेंटिटी",
          description: "consistent कलर्स, typography, और layout स्टाइल ताकि आपका ब्रांड पहचानने योग्य और भरोसेमंद हो।",
        },
        {
          title: "एड क्रिएटिव डिज़ाइन",
          description: "high-converting creatives जो क्लिक्स, इंक्वायरीज़, और कैंपेन परफॉर्मेंस इम्प्रूव करने के लिए डिज़ाइन की गई हैं।",
        },
        {
          title: "कंटेंट प्लानिंग सपोर्ट",
          description: "structured विज़ुअल प्लानिंग ताकि आपका सोशल मीडिया consistent, प्रोफेशनल, और growth-focused रहे।",
        },
      ],
    },
    footer: {
      description: "Scroll-stopping विज़ुअल्स और स्ट्रैटेजिक कंटेंट जो attention को एंगेजमेंट में और एंगेजमेंट को results में कन्वर्ट करे।",
      quickLinks: "क्विक लिंक्स",
      servicesTitle: "सेवाएं",
      getInTouch: "संपर्क करें",
      availableWorldwide: "दुनिया भर में उपलब्ध",
      copyright: "© 2026 DesignWithSajid | सर्वाधिकार सुरक्षित",
      privacyPolicy: "प्राइवेसी पॉलिसी",
      termsOfService: "सेवा की शर्तें",
    },
  },
  zh: {
    nav: {
      home: "首页",
      services: "服务",
      portfolio: "作品集",
      results: "成果",
      contact: "联系",
      freeCall: "免费策略通话",
    },
    hero: {
      badge: "受到全球50+品牌的信赖",
      title: "您的品牌在社交媒体上",
      titleHighlight: "隐形了吗？",
      subtitle: "现实是：",
      description:
        "您在发帖，但互动为零。粉丝没有增长。没有销售。我用吸睛的设计和战略内容来转变您的品牌，抓住注意力并转化客户。",
      cta: "预约免费策略通话",
      ctaSecondary: "查看作品集",
      happyClients: "50+满意客户",
      rating: "5.0评分",
      engagement: "互动",
      engagementLabel: "平均增长",
      projects: "项目",
      projectsLabel: "已完成",
      conversion: "转化",
      conversionLabel: "客户留存",
      turnaround: "交付",
      turnaroundLabel: "交付时间",
      brandGrowth: "与我合作后的品牌增长",
      rated: "#1评级",
      revenueImpact: "收入影响",
      monthlyGrowth: "月度增长趋势",
      thisMonth: "本月+24%",
    },
    problem: {
      badge: "这是您的故事吗？",
      title: "为什么您在",
      titleHighlight: "社交媒体上挣扎？",
      description: "如果您面临这些问题，您并不孤单。90%的企业面临同样的挑战。但有解决方案——我可以给您正是那个。",
      bottomQuestion: "您也面临这些问题吗？",
      bottomSolution: "别担心——解决方案在下面",
      problems: [
        {
          title: "隐形帖子",
          description: "您的帖子在前3秒内无法吸引注意——算法忽视您",
          stat: "70%",
          statLabel: "帖子无人问津",
        },
        {
          title: "通用设计",
          description: "Canva模板看起来都一样——您的品牌在人群中迷失",
          stat: "89%",
          statLabel: "品牌使用相同外观",
        },
        {
          title: "品牌不一致",
          description: "每个帖子看起来不同——客户困惑，信任无法建立",
          stat: "60%",
          statLabel: "因不一致而失去信任",
        },
        {
          title: "点赞但无销售",
          description: "获得互动但没有询问或销售——内容策略缺失",
          stat: "95%",
          statLabel: "无策略内容失败",
        },
        {
          title: "预算浪费",
          description: "在广告上花钱但ROI为负——定位和创意都很弱",
          stat: "¥3500+",
          statLabel: "平均每月浪费",
        },
        {
          title: "时间消耗",
          description: "花几个小时创建内容但结果为零——生产力损失",
          stat: "15+小时",
          statLabel: "每周浪费在DIY内容上",
        },
      ],
    },
    solution: {
      badge: "您的解决方案在这里",
      title: "战略设计 + 智能内容 = 增长",
      description:
        "我不仅仅是设计师——我是您的增长伙伴。每个设计背后都有策略，每个帖子都有目标。结果？您的品牌位居榜首。",
      processTitle: "简单4步流程",
      processSubtitle: "只需4步从困惑变为自信",
      cta: "预约您的免费策略通话",
      ctaSubtext: "无承诺——只有价值",
      solutions: [
        { title: "停止滚动的视觉效果", description: "在0.5秒内吸引注意的设计——算法认可", benefit: "保证5倍以上覆盖" },
        { title: "战略内容规划", description: "每个帖子都有目的——从认知到转化的旅程规划", benefit: "清晰的销售路径" },
        { title: "高端品牌形象", description: "一致且令人难忘的品牌外观，建立信任和权威", benefit: "从竞争中脱颖而出" },
        { title: "基于心理学的设计", description: "经科学证明能提升互动的颜色、字体和布局", benefit: "更高的转化率" },
        { title: "数据驱动优化", description: "跟踪性能并持续改进内容", benefit: "月度增长" },
        { title: "快速交付", description: "48小时内交付专业内容——无需再等待", benefit: "永不错过趋势" },
      ],
      process: [
        { title: "发现通话", desc: "了解您的品牌和目标" },
        { title: "策略计划", desc: "制定定制内容策略" },
        { title: "设计与创作", desc: "创作优质内容" },
        { title: "发布与增长", desc: "跟踪和优化结果" },
      ],
    },
    services: {
      badge: "我的服务",
      title: "我能为您的品牌做什么",
      description: "我提供完整的社交媒体内容和设计解决方案，让您可以专注于业务，而我处理您的在线形象。",
      benefitsTitle: "与我合作您将获得",
      benefits: [
        "强大且专业的品牌形象",
        "更高的互动和覆盖",
        "吸引正确受众的内容",
        "从社交媒体获得更好的转化",
        "用现成内容节省时间",
        "清晰的策略而非随机发帖",
      ],
      servicesList: [
        { title: "社交媒体内容创作", description: "帖子创意、内容方向和视觉规划，旨在提高互动和品牌知名度。" },
        { title: "社交媒体图形设计", description: "专业的帖子、轮播、故事和广告创意，停止滚动并提升您的品牌形象。" },
        { title: "品牌视觉识别", description: "一致的颜色、字体和布局风格，使您的品牌可识别且值得信赖。" },
        { title: "广告创意设计", description: "高转化创意，旨在提高点击、询问和活动效果。" },
        { title: "内容规划支持", description: "结构化的视觉规划，使您的社交媒体保持一致、专业和以增长为导向。" },
      ],
    },
    footer: {
      description: "停止滚动的视觉效果和战略内容，将注意力转化为互动，将互动转化为结果。",
      quickLinks: "快速链接",
      servicesTitle: "服务",
      getInTouch: "联系我们",
      availableWorldwide: "全球可用",
      copyright: "© 2026 DesignWithSajid | 版权所有",
      privacyPolicy: "隐私政策",
      termsOfService: "服务条款",
    },
  },
  pt: {
    nav: {
      home: "Início",
      services: "Serviços",
      portfolio: "Portfólio",
      results: "Resultados",
      contact: "Contato",
      freeCall: "Chamada Estratégica Grátis",
    },
    hero: {
      badge: "Confiança de mais de 50 marcas em todo o mundo",
      title: "Sua Marca é",
      titleHighlight: "Invisível nas Redes Sociais?",
      subtitle: "Realidade:",
      description:
        "Você está postando conteúdo, mas o engajamento é zero. Seguidores não crescem. Vendas não chegam. Eu transformo sua marca com designs que param o scroll e conteúdo estratégico que capta atenção e converte clientes.",
      cta: "Agende sua Chamada Estratégica Grátis",
      ctaSecondary: "Ver Portfólio",
      happyClients: "50+ Clientes Satisfeitos",
      rating: "Avaliação 5.0",
      engagement: "Engajamento",
      engagementLabel: "Aumento Médio",
      projects: "Projetos",
      projectsLabel: "Concluídos",
      conversion: "Conversão",
      conversionLabel: "Retenção de Clientes",
      turnaround: "Entrega",
      turnaroundLabel: "Tempo de Entrega",
      brandGrowth: "Crescimento da Marca Após Trabalhar Comigo",
      rated: "#1 Avaliado",
      revenueImpact: "Impacto na Receita",
      monthlyGrowth: "Tendência de Crescimento Mensal",
      thisMonth: "+24% este mês",
    },
    problem: {
      badge: "Essa é Sua História?",
      title: "Por Que Você Está",
      titleHighlight: "Lutando nas Redes Sociais?",
      description:
        "Se você está enfrentando esses problemas, você não está sozinho. 90% dos negócios enfrentam os mesmos desafios. Mas há uma solução - e eu posso te dar exatamente isso.",
      bottomQuestion: "Você também enfrenta esses problemas?",
      bottomSolution: "Não se preocupe - a solução está abaixo",
      problems: [
        {
          title: "Posts Invisíveis",
          description: "Seus posts não captam atenção nos primeiros 3 segundos - o algoritmo ignora você",
          stat: "70%",
          statLabel: "dos posts não são vistos",
        },
        {
          title: "Designs Genéricos",
          description: "Templates do Canva todos parecem iguais - sua marca se perde na multidão",
          stat: "89%",
          statLabel: "das marcas usam o mesmo visual",
        },
        {
          title: "Branding Inconsistente",
          description: "Cada post parece diferente - clientes estão confusos e a confiança não se constrói",
          stat: "60%",
          statLabel: "perda de confiança por inconsistência",
        },
        {
          title: "Curtidas Mas Sem Vendas",
          description: "Você recebe engajamento mas sem consultas ou vendas - estratégia de conteúdo está faltando",
          stat: "95%",
          statLabel: "conteúdo sem estratégia falha",
        },
        {
          title: "Orçamento Desperdiçado",
          description: "Gastando em anúncios mas ROI é negativo - segmentação e criativo ambos fracos",
          stat: "R$2500+",
          statLabel: "desperdiçado mensalmente em média",
        },
        {
          title: "Desperdício de Tempo",
          description: "Horas gastas criando conteúdo mas resultados zero - perda de produtividade",
          stat: "15+ hrs",
          statLabel: "por semana desperdiçadas em conteúdo DIY",
        },
      ],
    },
    solution: {
      badge: "Sua Solução Está Aqui",
      title: "Design Estratégico + Conteúdo Inteligente = Crescimento",
      description:
        "Eu não sou apenas um designer - sou seu parceiro de crescimento. Cada design tem estratégia por trás, cada post tem um objetivo. Resultado? Sua marca no topo.",
      processTitle: "Processo Simples de 4 Passos",
      processSubtitle: "De confuso a confiante em apenas 4 passos",
      cta: "Agende sua Chamada Estratégica Grátis",
      ctaSubtext: "Sem compromisso - apenas valor",
      solutions: [
        {
          title: "Visuais que Param o Scroll",
          description: "Designs que captam atenção nos primeiros 0.5 segundos - aprovados pelo algoritmo",
          benefit: "5x mais alcance garantido",
        },
        {
          title: "Planejamento Estratégico de Conteúdo",
          description: "Cada post com propósito - jornada planejada da consciência à conversão",
          benefit: "Caminho claro para vendas",
        },
        {
          title: "Identidade de Marca Premium",
          description: "Visual de marca consistente e memorável que constrói confiança e autoridade",
          benefit: "Destaque-se da concorrência",
        },
        {
          title: "Design Baseado em Psicologia",
          description: "Cores, fontes e layouts cientificamente comprovados para aumentar engajamento",
          benefit: "Maiores taxas de conversão",
        },
        {
          title: "Otimização Baseada em Dados",
          description: "Acompanhe o desempenho e melhore continuamente o conteúdo",
          benefit: "Crescimento mês a mês",
        },
        {
          title: "Entrega Rápida",
          description: "Entrega de conteúdo profissional em 48 horas - sem mais espera",
          benefit: "Nunca perca uma tendência",
        },
      ],
      process: [
        { title: "Chamada de Descoberta", desc: "Entender sua marca e objetivos" },
        { title: "Plano de Estratégia", desc: "Desenvolver estratégia de conteúdo personalizada" },
        { title: "Projetar e Criar", desc: "Criar conteúdo premium" },
        { title: "Lançar e Crescer", desc: "Acompanhar e otimizar resultados" },
      ],
    },
    services: {
      badge: "Meus Serviços",
      title: "O Que Posso Fazer Pela Sua Marca",
      description:
        "Eu ofereço soluções completas de conteúdo e design para redes sociais para que você possa focar no seu negócio enquanto eu cuido da sua presença online.",
      benefitsTitle: "O Que Você Ganha Trabalhando Comigo",
      benefits: [
        "Presença de marca forte e profissional",
        "Maior engajamento e alcance",
        "Conteúdo que atrai o público certo",
        "Melhor conversão das redes sociais",
        "Tempo economizado com conteúdo pronto",
        "Estratégia clara em vez de posts aleatórios",
      ],
      servicesList: [
        {
          title: "Criação de Conteúdo para Redes Sociais",
          description:
            "Ideias de posts, direção de conteúdo e planejamento visual projetados para aumentar engajamento e conhecimento de marca.",
        },
        {
          title: "Design Gráfico para Redes Sociais",
          description:
            "Posts profissionais, carrosséis, stories e criativos de anúncios que param o scroll e elevam sua imagem de marca.",
        },
        {
          title: "Identidade Visual de Marca",
          description:
            "Cores consistentes, tipografia e estilo de layout para tornar sua marca reconhecível e confiável.",
        },
        {
          title: "Design de Criativos para Anúncios",
          description:
            "Criativos de alta conversão projetados para melhorar cliques, consultas e desempenho de campanhas.",
        },
        {
          title: "Suporte de Planejamento de Conteúdo",
          description:
            "Planejamento visual estruturado para que suas redes sociais permaneçam consistentes, profissionais e focadas em crescimento.",
        },
      ],
    },
    footer: {
      description:
        "Visuais que param o scroll e conteúdo estratégico que converte atenção em engajamento e engajamento em resultados.",
      quickLinks: "Links Rápidos",
      servicesTitle: "Serviços",
      getInTouch: "Entre em Contato",
      availableWorldwide: "Disponível Mundialmente",
      copyright: "© 2026 DesignWithSajid | Todos os Direitos Reservados",
      privacyPolicy: "Política de Privacidade",
      termsOfService: "Termos de Serviço",
    },
  },
  tr: {
    nav: {
      home: "Ana Sayfa",
      services: "Hizmetler",
      portfolio: "Portföy",
      results: "Sonuçlar",
      contact: "İletişim",
      freeCall: "Ücretsiz Strateji Görüşmesi",
    },
    hero: {
      badge: "Dünya genelinde 50+ markanın güveni",
      title: "Markanız Sosyal Medyada",
      titleHighlight: "Görünmez mi?",
      subtitle: "Gerçek:",
      description:
        "İçerik paylaşıyorsunuz ama etkileşim sıfır. Takipçiler artmıyor. Satış gelmiyor. Markanızı dikkat çeken tasarımlar ve stratejik içerikle dönüştürüyorum.",
      cta: "Ücretsiz Strateji Görüşmesi Ayırtın",
      ctaSecondary: "Portföyü Görüntüle",
      happyClients: "50+ Mutlu Müşteri",
      rating: "5.0 Puan",
      engagement: "Etkileşim",
      engagementLabel: "Ortalama Artış",
      projects: "Projeler",
      projectsLabel: "Tamamlandı",
      conversion: "Dönüşüm",
      conversionLabel: "Müşteri Tutma",
      turnaround: "Teslimat",
      turnaroundLabel: "Teslimat Süresi",
      brandGrowth: "Benimle Çalıştıktan Sonra Marka Büyümesi",
      rated: "#1 Değerlendirilen",
      revenueImpact: "Gelir Etkisi",
      monthlyGrowth: "Aylık Büyüme Trendi",
      thisMonth: "Bu ay +%24",
    },
    problem: {
      badge: "Bu Sizin Hikayeniz mi?",
      title: "Neden Sosyal Medyada",
      titleHighlight: "Zorlanıyorsunuz?",
      description:
        "Bu sorunlarla karşılaşıyorsanız yalnız değilsiniz. İşletmelerin %90'ı aynı zorluklarla karşılaşıyor. Ama bir çözüm var - ve size tam olarak bunu verebilirim.",
      bottomQuestion: "Siz de bu sorunlarla karşılaşıyor musunuz?",
      bottomSolution: "Endişelenmeyin - çözüm aşağıda",
      problems: [
        {
          title: "Görünmez Gönderiler",
          description: "Gönderileriniz ilk 3 saniyede dikkat çekmiyor - algoritma sizi görmezden geliyor",
          stat: "%70",
          statLabel: "gönderi görünmüyor",
        },
        {
          title: "Jenerik Tasarımlar",
          description: "Canva şablonları hep aynı görünüyor - markanız kalabalıkta kayboluyor",
          stat: "%89",
          statLabel: "markalar aynı görünümü kullanıyor",
        },
        {
          title: "Tutarsız Marka",
          description: "Her gönderi farklı görünüyor - müşteriler kafası karışık ve güven oluşmuyor",
          stat: "%60",
          statLabel: "tutarsızlık nedeniyle güven kaybı",
        },
        {
          title: "Beğeni Var Satış Yok",
          description: "Etkileşim alıyorsunuz ama sorgu veya satış yok - içerik stratejisi eksik",
          stat: "%95",
          statLabel: "stratejisiz içerik başarısız",
        },
        {
          title: "Boşa Giden Bütçe",
          description: "Reklamlara harcıyorsunuz ama ROI negatif - hedefleme ve yaratıcılık zayıf",
          stat: "₺15K+",
          statLabel: "ortalama aylık israf",
        },
        {
          title: "Zaman Kaybı",
          description: "İçerik oluşturmaya saatler harcıyorsunuz ama sonuç sıfır - verimlilik kaybı",
          stat: "15+ saat",
          statLabel: "haftalık DIY içeriğe harcanan",
        },
      ],
    },
    solution: {
      badge: "Çözümünüz Burada",
      title: "Stratejik Tasarım + Akıllı İçerik = Büyüme",
      description:
        "Ben sadece tasarımcı değilim - büyüme ortağınızım. Her tasarımın arkasında strateji var, her gönderinin bir amacı var. Sonuç? Markanız zirvede.",
      processTitle: "Basit 4 Adımlı Süreç",
      processSubtitle: "Sadece 4 adımda karışıklıktan güvene",
      cta: "Ücretsiz Strateji Görüşmenizi Ayırtın",
      ctaSubtext: "Taahhüt yok - sadece değer",
      solutions: [
        {
          title: "Kaydırmayı Durduran Görseller",
          description: "İlk 0.5 saniyede dikkat çeken tasarımlar - algoritma onaylı",
          benefit: "5 kat daha fazla erişim garantili",
        },
        {
          title: "Stratejik İçerik Planlaması",
          description: "Her gönderi bir amaçla - farkındalıktan dönüşüme yolculuk planlandı",
          benefit: "Satışa giden net yol",
        },
        {
          title: "Premium Marka Kimliği",
          description: "Güven ve otorite oluşturan tutarlı ve unutulmaz marka görünümü",
          benefit: "Rekabetten sıyrılın",
        },
        {
          title: "Psikoloji Tabanlı Tasarım",
          description: "Etkileşimi artırmak için bilimsel olarak kanıtlanmış renkler, fontlar ve düzenler",
          benefit: "Daha yüksek dönüşüm oranları",
        },
        {
          title: "Veri Odaklı Optimizasyon",
          description: "Performansı takip edin ve içeriği sürekli iyileştirin",
          benefit: "Aydan aya büyüme",
        },
        {
          title: "Hızlı Teslimat",
          description: "48 saat içinde profesyonel içerik teslimatı - artık bekleme yok",
          benefit: "Hiçbir trendi kaçırmayın",
        },
      ],
      process: [
        { title: "Keşif Görüşmesi", desc: "Markanızı ve hedeflerinizi anlamak" },
        { title: "Strateji Planı", desc: "Özel içerik stratejisi geliştirmek" },
        { title: "Tasarla ve Oluştur", desc: "Premium içerik oluşturmak" },
        { title: "Başlat ve Büyü", desc: "Sonuçları takip et ve optimize et" },
      ],
    },
    services: {
      badge: "Hizmetlerim",
      title: "Markanız İçin Neler Yapabilirim",
      description:
        "Siz işinize odaklanırken ben çevrimiçi varlığınızı yöneteyim diye eksiksiz sosyal medya içerik ve tasarım çözümleri sunuyorum.",
      benefitsTitle: "Benimle Çalışarak Kazanacaklarınız",
      benefits: [
        "Güçlü ve profesyonel marka varlığı",
        "Daha yüksek etkileşim ve erişim",
        "Doğru kitleyi çeken içerik",
        "Sosyal medyadan daha iyi dönüşüm",
        "Hazır içerikle zaman tasarrufu",
        "Rastgele paylaşım yerine net strateji",
      ],
      servicesList: [
        {
          title: "Sosyal Medya İçerik Oluşturma",
          description:
            "Etkileşimi ve marka bilinirliğini artırmak için tasarlanmış gönderi fikirleri, içerik yönlendirmesi ve görsel planlama.",
        },
        {
          title: "Sosyal Medya için Grafik Tasarım",
          description:
            "Kaydırmayı durduran ve marka imajınızı yükselten profesyonel gönderiler, karuseller, hikayeler ve reklam kreatifleri.",
        },
        {
          title: "Marka Görsel Kimliği",
          description: "Markanızı tanınır ve güvenilir kılmak için tutarlı renkler, tipografi ve düzen stili.",
        },
        {
          title: "Reklam Kreatif Tasarımı",
          description:
            "Tıklamaları, sorguları ve kampanya performansını artırmak için tasarlanmış yüksek dönüşümlü kreatifler.",
        },
        {
          title: "İçerik Planlama Desteği",
          description:
            "Sosyal medyanızın tutarlı, profesyonel ve büyüme odaklı kalması için yapılandırılmış görsel planlama.",
        },
      ],
    },
    footer: {
      description:
        "Dikkati etkileşime ve etkileşimi sonuçlara dönüştüren kaydırmayı durduran görseller ve stratejik içerik.",
      quickLinks: "Hızlı Bağlantılar",
      servicesTitle: "Hizmetler",
      getInTouch: "İletişime Geçin",
      availableWorldwide: "Dünya Genelinde Mevcut",
      copyright: "© 2026 DesignWithSajid | Tüm Hakları Saklıdır",
      privacyPolicy: "Gizlilik Politikası",
      termsOfService: "Hizmet Şartları",
    },
  },
}
