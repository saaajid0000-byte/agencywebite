"use client"

import { useEffect, useRef, useState } from "react"
import { AlertCircle, Eye, Layers, Shuffle, Target, DollarSign, Clock, XCircle, TrendingDown } from "lucide-react"
import { useLanguage } from "@/components/language-provider"

const iconMap = [Eye, Layers, Shuffle, Target, DollarSign, Clock]

export function Problem() {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const { t, isRTL } = useLanguage()

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={ref} className="py-24 bg-card border-y border-border relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 text-destructive">
          <XCircle className="w-40 h-40" />
        </div>
        <div className="absolute bottom-10 right-10 text-destructive">
          <TrendingDown className="w-32 h-32" />
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 ${isRTL ? "direction-rtl" : ""}`}>
          <div
            className={`inline-flex items-center gap-2 bg-destructive/10 border border-destructive/30 rounded-full px-4 py-2 mb-6 ${isRTL ? "flex-row-reverse" : ""}`}
          >
            <AlertCircle className="w-4 h-4 text-destructive" />
            <span className="text-sm text-destructive font-medium">{t.problem.badge}</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
            {t.problem.title} <span className="text-destructive">{t.problem.titleHighlight}</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty">{t.problem.description}</p>
        </div>

        {/* Problems Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {t.problem.problems.map((problem, index) => {
            const Icon = iconMap[index]
            return (
              <div
                key={index}
                className={`group p-6 bg-background border border-border rounded-xl hover:border-destructive/50 transition-all duration-500 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className={`flex items-start gap-4 ${isRTL ? "flex-row-reverse text-right" : ""}`}>
                  <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center shrink-0 group-hover:bg-destructive/20 transition-colors">
                    <Icon className="w-6 h-6 text-destructive" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">{problem.title}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{problem.description}</p>
                    <div className={`flex items-center gap-2 ${isRTL ? "flex-row-reverse" : ""}`}>
                      <span className="text-xl font-bold text-destructive">{problem.stat}</span>
                      <span className="text-xs text-muted-foreground">{problem.statLabel}</span>
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Bottom CTA */}
        <div
          className={`text-center mt-16 p-8 bg-background border border-border rounded-2xl ${isRTL ? "direction-rtl" : ""}`}
        >
          <p className="text-xl text-foreground font-medium mb-2">{t.problem.bottomQuestion}</p>
          <p className="text-muted-foreground mb-6">
            {t.problem.bottomSolution.split(" - ")[0]} -{" "}
            <span className="text-accent font-semibold">{t.problem.bottomSolution.split(" - ")[1]}</span>
          </p>
          <div className="flex justify-center">
            <div className="w-8 h-8 border-2 border-accent rounded-full flex items-center justify-center animate-bounce">
              <svg className="w-4 h-4 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
