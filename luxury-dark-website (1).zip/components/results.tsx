import { TrendingUp } from "lucide-react"

const stats = [
  {
    value: "+150%",
    label: "Average Engagement Increase",
    description: "Clients see significant boost in likes, comments, and shares",
  },
  {
    value: "+200%",
    label: "Brand Recognition Growth",
    description: "Stronger brand presence across all platforms",
  },
  {
    value: "+120%",
    label: "Conversion Rate Improvement",
    description: "More inquiries and sales from social media",
  },
]

export function Results() {
  return (
    <section id="results" className="py-24 bg-card border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-2 mb-6">
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Results</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
            Growth Focused Outcomes
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Clients see improved engagement, stronger brand identity, and better response from their audience through
            consistent and strategic content.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="relative p-8 bg-background border border-border rounded-2xl text-center group hover:border-primary/50 transition-all duration-300"
            >
              {/* Decorative glow */}
              <div className="absolute inset-0 bg-primary/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" />

              <div className="relative">
                <div className="font-serif text-5xl md:text-6xl font-bold text-primary mb-2">{stat.value}</div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{stat.label}</h3>
                <p className="text-muted-foreground">{stat.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
