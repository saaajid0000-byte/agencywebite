"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { LanguageSelector } from "@/components/language-selector"
import { useLanguage } from "@/components/language-provider"

export function Header() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { t, isRTL } = useLanguage()

  const navLinks = [
    { href: "#home", label: t.nav.home },
    { href: "#services", label: t.nav.services },
    { href: "#portfolio", label: t.nav.portfolio },
    { href: "#results", label: t.nav.results },
    { href: "#contact", label: t.nav.contact },
  ]

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToContact = () => {
    const contactSection = document.getElementById("contact")
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth" })
    }
    setIsOpen(false)
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-background/95 backdrop-blur-xl shadow-lg border-b border-border" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className={`flex items-center justify-between h-14 sm:h-16 md:h-20 ${isRTL ? "flex-row-reverse" : ""}`}>
          <Link href="/" className="flex items-center gap-2 group flex-shrink-0">
            <Image
              src="/images/logo.png"
              alt="Design With Sajid"
              width={180}
              height={40}
              className="h-7 sm:h-8 md:h-10 w-auto"
              priority
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className={`hidden lg:flex items-center gap-6 xl:gap-8 ${isRTL ? "flex-row-reverse" : ""}`}>
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-muted-foreground hover:text-accent transition-colors text-sm font-medium relative group"
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-accent transition-all group-hover:w-full" />
              </Link>
            ))}
          </nav>

          <div className={`hidden lg:flex items-center gap-2 xl:gap-3 ${isRTL ? "flex-row-reverse" : ""}`}>
            <LanguageSelector />
            <ThemeToggle />
            <Button
              onClick={scrollToContact}
              size="sm"
              className="bg-accent text-accent-foreground hover:bg-accent/90 shadow-lg text-sm px-4"
            >
              {t.nav.freeCall}
            </Button>
          </div>

          <div className={`flex lg:hidden items-center gap-1 sm:gap-2 ${isRTL ? "flex-row-reverse" : ""}`}>
            <LanguageSelector />
            <ThemeToggle />
            <button
              className="text-foreground p-1.5 sm:p-2 hover:bg-accent/10 rounded-lg transition-colors"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="w-5 h-5 sm:w-6 sm:h-6" /> : <Menu className="w-5 h-5 sm:w-6 sm:h-6" />}
            </button>
          </div>
        </div>

        {isOpen && (
          <div className="lg:hidden absolute left-0 right-0 top-full py-4 px-3 border-t border-border bg-background/98 backdrop-blur-xl shadow-xl">
            <nav className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`text-foreground hover:text-accent hover:bg-accent/10 transition-colors text-base font-medium px-4 py-3 rounded-lg ${isRTL ? "text-right" : ""}`}
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <Button
                onClick={scrollToContact}
                className="bg-accent text-accent-foreground hover:bg-accent/90 w-full mt-4 py-6"
              >
                {t.nav.freeCall}
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
