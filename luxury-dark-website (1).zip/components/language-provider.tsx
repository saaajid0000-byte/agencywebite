"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { type Language, translations, languageNames } from "@/lib/translations"

type LanguageContextType = {
  language: Language
  setLanguage: (lang: Language) => void
  t: typeof translations.en
  languageNames: typeof languageNames
  isRTL: boolean
}

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: translations.en,
  languageNames,
  isRTL: false,
})

function detectLanguage(): Language {
  if (typeof window === "undefined") return "en"

  const browserLang = navigator.language || (navigator as unknown as { userLanguage?: string }).userLanguage || "en"
  const langCode = browserLang.split("-")[0].toLowerCase()

  const langMap: Record<string, Language> = {
    en: "en",
    ur: "ur",
    ar: "ar",
    es: "es",
    fr: "fr",
    de: "de",
    hi: "hi",
    zh: "zh",
    pt: "pt",
    tr: "tr",
  }

  return langMap[langCode] || "en"
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("en")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    // Check localStorage first, then detect from browser
    const savedLang = localStorage.getItem("language") as Language | null
    const detectedLang = savedLang || detectLanguage()
    setLanguageState(detectedLang)
    setMounted(true)
  }, [])

  const setLanguage = (lang: Language) => {
    setLanguageState(lang)
    localStorage.setItem("language", lang)
  }

  const isRTL = language === "ur" || language === "ar"

  // Update document direction for RTL languages
  useEffect(() => {
    if (mounted) {
      document.documentElement.dir = isRTL ? "rtl" : "ltr"
      document.documentElement.lang = language
    }
  }, [language, isRTL, mounted])

  const value: LanguageContextType = {
    language,
    setLanguage,
    t: translations[language],
    languageNames,
    isRTL,
  }

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  return useContext(LanguageContext)
}
