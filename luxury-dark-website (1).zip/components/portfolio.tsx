"use client"

import { Sparkles, ExternalLink } from "lucide-react"
import Image from "next/image"

const portfolioItems = [
  {
    title: "Brand Identity Design",
    category: "Branding",
    image: "/luxury-brand-identity-design-dark-gold.jpg",
  },
  {
    title: "Social Media Campaign",
    category: "Social Media",
    image: "/premium-social-media-campaign-design.jpg",
  },
  {
    title: "Ad Creative Design",
    category: "Advertising",
    image: "/luxury-ad-creative-design-dark-theme.jpg",
  },
  {
    title: "Instagram Carousel",
    category: "Social Media",
    image: "/elegant-instagram-carousel-design.jpg",
  },
  {
    title: "Logo & Branding",
    category: "Branding",
    image: "/premium-logo-design-dark-background.jpg",
  },
  {
    title: "Content Strategy",
    category: "Planning",
    image: "/content-strategy-visual-design-premium.jpg",
  },
]

export function Portfolio() {
  return (
    <section id="portfolio" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-2 mb-6">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Portfolio</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
            Selected Work
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            My portfolio focuses on real-world social media designs created for brands that want to stand out, look
            premium, and grow consistently. Each project is designed with purpose, clarity, and performance in mind.
          </p>
        </div>

        {/* Portfolio Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {portfolioItems.map((item, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-xl border border-border bg-card cursor-pointer"
            >
              <div className="aspect-[3/2] relative overflow-hidden">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-3">
                      <ExternalLink className="w-5 h-5 text-primary" />
                    </div>
                    <span className="text-foreground font-medium">View Project</span>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <span className="text-xs text-primary font-medium uppercase tracking-wider">{item.category}</span>
                <h3 className="font-semibold text-foreground mt-1">{item.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
