"use client"

import { useState, useEffect, useCallback } from "react"
import { Star, ChevronLeft, ChevronRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const testimonials = [
  {
    name: "Michael T.",
    time: "2 weeks ago",
    content:
      "Sajid completely transformed our social media presence! Our engagement increased by 200% in just 3 months. The designs are professional and the content strategy is spot on. Best investment we made for our brand.",
  },
  {
    name: "Jennifer M.",
    time: "1 month ago",
    content:
      "Working with Sajid has been a game-changer for our business. He understands our brand perfectly and creates content that truly resonates with our audience. Our followers love the new designs and engagement has tripled!",
  },
  {
    name: "David R.",
    time: "3 weeks ago",
    content:
      "Best graphic designer I've ever worked with! Sajid's attention to detail and creative vision helped us stand out from competitors. The ROI has been incredible - our sales increased by 40% after the rebrand.",
  },
  {
    name: "Sarah W.",
    time: "1 week ago",
    content:
      "Sajid created a complete brand identity for our startup. The designs are modern, professional, and perfectly aligned with our vision. We've received so many compliments from customers and investors alike.",
  },
  {
    name: "Robert K.",
    time: "2 months ago",
    content:
      "Outstanding work! Sajid's content strategy helped us reach our target audience effectively. The designs are eye-catching and our conversion rate improved by 65%. Highly recommend his services!",
  },
  {
    name: "Emily C.",
    time: "3 weeks ago",
    content:
      "Professional, creative, and always delivers on time! Sajid understands our brand voice and creates content that converts. Our social media has never looked better. Worth every penny!",
  },
  {
    name: "James L.",
    time: "1 month ago",
    content:
      "Sajid's designs are absolutely stunning. He took our boring social media and turned it into something that actually gets attention. Our follower count doubled in just 2 months. Amazing work!",
  },
  {
    name: "Amanda P.",
    time: "2 weeks ago",
    content:
      "I was struggling with my brand identity for months until I found Sajid. He delivered exactly what I needed - clean, professional, and memorable designs. My business looks so much more credible now.",
  },
]

function GoogleLogo({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
        fill="#4285F4"
      />
      <path
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
        fill="#34A853"
      />
      <path
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
        fill="#FBBC05"
      />
      <path
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
        fill="#EA4335"
      />
    </svg>
  )
}

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)
  const [itemsPerView, setItemsPerView] = useState(1)

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setItemsPerView(3)
      } else if (window.innerWidth >= 640) {
        setItemsPerView(2)
      } else {
        setItemsPerView(1)
      }
    }
    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const maxIndex = Math.max(0, testimonials.length - itemsPerView)

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev >= maxIndex ? 0 : prev + 1))
  }, [maxIndex])

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? maxIndex : prev - 1))
  }

  useEffect(() => {
    if (!isAutoPlaying) return
    const interval = setInterval(nextSlide, 4000)
    return () => clearInterval(interval)
  }, [isAutoPlaying, nextSlide])

  const slideWidth = 100 / itemsPerView

  return (
    <section className="py-16 sm:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-8 sm:mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-3 sm:px-4 py-1.5 sm:py-2 mb-4 sm:mb-6">
            <GoogleLogo className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="text-xs sm:text-sm text-primary font-medium">Google Reviews</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-3 sm:mb-4 text-balance">
            What Clients Say About My Work
          </h2>
          <div className="flex items-center justify-center gap-2 mt-3 sm:mt-4">
            <div className="flex gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 fill-yellow-400 text-yellow-400" />
              ))}
            </div>
            <span className="text-foreground font-semibold text-sm sm:text-base">5.0</span>
            <span className="text-muted-foreground text-sm">({testimonials.length} reviews)</span>
          </div>
        </div>

        {/* Carousel Container */}
        <div
          className="relative"
          onMouseEnter={() => setIsAutoPlaying(false)}
          onMouseLeave={() => setIsAutoPlaying(true)}
        >
          <Button
            variant="outline"
            size="icon"
            onClick={prevSlide}
            className="absolute left-0 lg:-left-4 xl:-left-6 top-1/2 -translate-y-1/2 z-10 bg-background border-border hover:bg-accent/10 hover:border-accent hidden sm:flex w-8 h-8 sm:w-10 sm:h-10"
          >
            <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          </Button>

          <Button
            variant="outline"
            size="icon"
            onClick={nextSlide}
            className="absolute right-0 lg:-right-4 xl:-right-6 top-1/2 -translate-y-1/2 z-10 bg-background border-border hover:bg-accent/10 hover:border-accent hidden sm:flex w-8 h-8 sm:w-10 sm:h-10"
          >
            <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
          </Button>

          {/* Testimonials Slider */}
          <div className="overflow-hidden px-0 sm:px-8 lg:px-2">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * slideWidth}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="flex-shrink-0 px-2 sm:px-3" style={{ width: `${slideWidth}%` }}>
                  <Card className="h-full bg-card border-border hover:border-primary/30 transition-all duration-300">
                    <CardContent className="p-4 sm:p-6">
                      {/* Google Header */}
                      <div className="flex items-center justify-between mb-3 sm:mb-4">
                        <GoogleLogo className="w-5 h-5 sm:w-6 sm:h-6" />
                        <span className="text-[10px] sm:text-xs text-muted-foreground">{testimonial.time}</span>
                      </div>

                      {/* Stars */}
                      <div className="flex gap-0.5 mb-3 sm:mb-4">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 sm:w-4 sm:h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>

                      {/* Content */}
                      <p className="text-muted-foreground mb-4 sm:mb-6 leading-relaxed text-xs sm:text-sm line-clamp-4">
                        {testimonial.content}
                      </p>

                      {/* Author */}
                      <div className="flex items-center gap-2 sm:gap-3">
                        <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-primary flex items-center justify-center">
                          <span className="text-xs sm:text-sm font-semibold text-primary-foreground">
                            {testimonial.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <div className="font-semibold text-foreground text-xs sm:text-sm">{testimonial.name}</div>
                          <div className="text-[10px] sm:text-xs text-muted-foreground flex items-center gap-1">
                            <span className="text-primary">Local Guide</span>
                            <span>•</span>
                            <span>15 reviews</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-center gap-3 mt-4 sm:hidden">
            <Button variant="outline" size="icon" onClick={prevSlide} className="bg-background border-border w-10 h-10">
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <Button variant="outline" size="icon" onClick={nextSlide} className="bg-background border-border w-10 h-10">
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-1.5 sm:gap-2 mt-4 sm:mt-6">
            {[...Array(maxIndex + 1)].map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIndex(i)}
                className={`h-1.5 sm:h-2 rounded-full transition-all duration-300 ${
                  i === currentIndex ? "w-4 sm:w-6 bg-accent" : "w-1.5 sm:w-2 bg-muted-foreground/30"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
