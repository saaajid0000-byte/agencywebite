"use client"

import Link from "next/link"
import Image from "next/image"
import { Instagram, Linkedin, Facebook, Mail, Phone, MapPin } from "lucide-react"
import { useLanguage } from "@/components/language-provider"

function XIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  )
}

function BehanceIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M22 7h-7v-2h7v2zm1.726 10c-.442 1.297-2.029 3-5.101 3-3.074 0-5.564-1.729-5.564-5.675 0-3.91 2.325-5.92 5.466-5.92 3.082 0 4.964 1.782 5.375 4.426.078.506.109 1.188.095 2.14h-8.027c.13 3.211 3.483 3.312 4.588 2.029h3.168zm-7.686-4h4.965c-.105-1.547-1.136-2.219-2.477-2.219-1.466 0-2.277.768-2.488 2.219zm-9.574 6.988h-6.466v-14.967h6.953c5.476.081 5.58 5.444 2.72 6.906 3.461 1.26 3.577 8.061-3.207 8.061zm-3.466-8.988h3.584c2.508 0 2.906-3-.312-3h-3.272v3zm3.391 3h-3.391v3.016h3.341c3.055 0 2.868-3.016.05-3.016z" />
    </svg>
  )
}

const socials = [
  { icon: Instagram, href: "https://www.instagram.com/m_saji90/", label: "Instagram" },
  { icon: Linkedin, href: "https://www.linkedin.com/in/sajid-iqbal90", label: "LinkedIn" },
  { icon: Facebook, href: "https://www.facebook.com/profile.php?id=61580312181209", label: "Facebook" },
  { icon: XIcon, href: "https://x.com/MaherSajid_90", label: "X" },
  { icon: BehanceIcon, href: "https://www.behance.net/mahersajid", label: "Behance" },
]

const serviceKeys = [
  "Social Media Content",
  "Graphic Design",
  "Brand Identity",
  "Ad Creative Design",
  "Content Planning",
  "Presentation Design",
]

export function Footer() {
  const { t, isRTL } = useLanguage()

  const quickLinks = [
    { href: "#home", label: t.nav.home },
    { href: "#services", label: t.nav.services },
    { href: "#portfolio", label: t.nav.portfolio },
    { href: "#results", label: t.nav.results },
    { href: "#contact", label: t.nav.contact },
  ]

  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        <div
          className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10 lg:gap-12 ${isRTL ? "direction-rtl" : ""}`}
        >
          {/* Brand */}
          <div className={`sm:col-span-2 lg:col-span-1 ${isRTL ? "text-right" : ""}`}>
            <Link href="/" className={`flex items-center gap-2 mb-4 ${isRTL ? "justify-end" : ""}`}>
              <Image
                src="/images/logo.png"
                alt="Design With Sajid"
                width={160}
                height={36}
                className="h-8 sm:h-9 w-auto"
              />
            </Link>
            <p className="text-muted-foreground text-sm leading-relaxed mb-4 sm:mb-6">{t.footer.description}</p>
            {/* Social Links */}
            <div className={`flex items-center gap-2 sm:gap-3 flex-wrap ${isRTL ? "justify-end" : ""}`}>
              {socials.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg bg-accent/10 border border-accent/30 flex items-center justify-center hover:bg-accent/20 transition-colors group"
                  aria-label={social.label}
                >
                  <social.icon className="w-4 h-4 sm:w-5 sm:h-5 text-accent group-hover:scale-110 transition-transform" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className={`${isRTL ? "text-right" : ""}`}>
            <h4 className="font-semibold text-foreground mb-3 sm:mb-4 text-sm sm:text-base">{t.footer.quickLinks}</h4>
            <ul className="space-y-2 sm:space-y-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className={`text-muted-foreground hover:text-accent transition-colors text-xs sm:text-sm flex items-center gap-2 group ${isRTL ? "flex-row-reverse" : ""}`}
                  >
                    <span className="w-1 h-1 sm:w-1.5 sm:h-1.5 rounded-full bg-accent/50 group-hover:bg-accent transition-colors" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div className={`${isRTL ? "text-right" : ""}`}>
            <h4 className="font-semibold text-foreground mb-3 sm:mb-4 text-sm sm:text-base">
              {t.footer.servicesTitle}
            </h4>
            <ul className="space-y-2 sm:space-y-3">
              {serviceKeys.map((service, index) => (
                <li key={index} className={`flex items-center gap-2 ${isRTL ? "flex-row-reverse" : ""}`}>
                  <span className="w-1 h-1 sm:w-1.5 sm:h-1.5 rounded-full bg-primary/50" />
                  <span className="text-muted-foreground text-xs sm:text-sm">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className={`${isRTL ? "text-right" : ""}`}>
            <h4 className="font-semibold text-foreground mb-3 sm:mb-4 text-sm sm:text-base">{t.footer.getInTouch}</h4>
            <ul className="space-y-3 sm:space-y-4 text-xs sm:text-sm">
              <li>
                <a
                  href="mailto:Sajid@designwithsajid.com"
                  className={`text-muted-foreground hover:text-accent transition-colors flex items-center gap-2 sm:gap-3 ${isRTL ? "flex-row-reverse" : ""}`}
                >
                  <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-3 h-3 sm:w-4 sm:h-4 text-accent" />
                  </div>
                  <span className="break-all">Sajid@designwithsajid.com</span>
                </a>
              </li>
              <li>
                <a
                  href="tel:+923007795242"
                  className={`text-muted-foreground hover:text-accent transition-colors flex items-center gap-2 sm:gap-3 ${isRTL ? "flex-row-reverse" : ""}`}
                >
                  <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-3 h-3 sm:w-4 sm:h-4 text-accent" />
                  </div>
                  +92 300 7795242
                </a>
              </li>
              <li className={`flex items-center gap-2 sm:gap-3 ${isRTL ? "flex-row-reverse" : ""}`}>
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-3 h-3 sm:w-4 sm:h-4 text-accent" />
                </div>
                <span className="text-muted-foreground">{t.footer.availableWorldwide}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div
          className={`border-t border-border mt-8 sm:mt-12 pt-6 sm:pt-8 flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4 ${isRTL ? "sm:flex-row-reverse" : ""}`}
        >
          <p className="text-muted-foreground text-xs sm:text-sm text-center sm:text-left">{t.footer.copyright}</p>
          <div className={`flex items-center gap-4 sm:gap-6 text-xs sm:text-sm ${isRTL ? "flex-row-reverse" : ""}`}>
            <Link href="#contact" className="text-muted-foreground hover:text-accent transition-colors">
              {t.footer.privacyPolicy}
            </Link>
            <Link href="#contact" className="text-muted-foreground hover:text-accent transition-colors">
              {t.footer.termsOfService}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
