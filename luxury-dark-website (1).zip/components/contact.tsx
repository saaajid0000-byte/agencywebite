"use client"

import { Mail, Phone, Globe, ArrowRight, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/components/language-provider"

export function Contact() {
  const { t, isRTL } = useLanguage()

  const whatsappLink =
    "https://api.whatsapp.com/send/?phone=923007795242&text=Hi%20Sajid!%20I%27m%20interested%20in%20your%20design%20services.&type=phone_number&app_absent=0"

  return (
    <section id="contact" className="py-24 bg-card border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`grid lg:grid-cols-2 gap-12 items-center ${isRTL ? "direction-rtl" : ""}`}>
          {/* Left Content */}
          <div className={`${isRTL ? "text-right" : ""}`}>
            <div
              className={`inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-2 mb-6 ${isRTL ? "flex-row-reverse" : ""}`}
            >
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm text-primary font-medium">{"Let's Work Together"}</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              Ready to Transform Your Brand?
            </h2>
            <p className="text-lg text-muted-foreground mb-8 text-pretty">
              If you want social media content that looks professional, builds trust, and drives real results,{" "}
              {"let's discuss your goals."} I would love to help you create something amazing.
            </p>

            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                className={`bg-accent text-accent-foreground hover:bg-accent/90 px-8 py-6 text-lg group animate-glow ${isRTL ? "flex-row-reverse" : ""}`}
              >
                Get a Free Strategy Call
                <ArrowRight
                  className={`w-5 h-5 ${isRTL ? "mr-2 group-hover:-translate-x-1" : "ml-2 group-hover:translate-x-1"} transition-transform`}
                />
              </Button>
            </a>
          </div>

          {/* Right Content - Contact Info */}
          <div className="bg-background border border-border rounded-2xl p-8 md:p-10">
            <h3 className={`font-serif text-2xl font-bold text-foreground mb-8 ${isRTL ? "text-right" : ""}`}>
              Get In Touch
            </h3>

            <div className="space-y-6">
              <a
                href="mailto:Sajid@designwithsajid.com"
                className={`flex items-start gap-4 group ${isRTL ? "flex-row-reverse" : ""}`}
              >
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                  <Mail className="w-5 h-5 text-primary" />
                </div>
                <div className={`${isRTL ? "text-right" : ""}`}>
                  <div className="text-sm text-muted-foreground mb-1">Email</div>
                  <span className="text-foreground group-hover:text-primary transition-colors font-medium">
                    Sajid@designwithsajid.com
                  </span>
                </div>
              </a>

              <a href="tel:+923007795242" className={`flex items-start gap-4 group ${isRTL ? "flex-row-reverse" : ""}`}>
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                  <Phone className="w-5 h-5 text-primary" />
                </div>
                <div className={`${isRTL ? "text-right" : ""}`}>
                  <div className="text-sm text-muted-foreground mb-1">Phone / WhatsApp</div>
                  <span className="text-foreground group-hover:text-primary transition-colors font-medium">
                    +92 300 7795242
                  </span>
                </div>
              </a>

              <div className={`flex items-start gap-4 ${isRTL ? "flex-row-reverse" : ""}`}>
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Globe className="w-5 h-5 text-primary" />
                </div>
                <div className={`${isRTL ? "text-right" : ""}`}>
                  <div className="text-sm text-muted-foreground mb-1">Availability</div>
                  <span className="text-foreground font-medium">Available Worldwide</span>
                </div>
              </div>
            </div>

            {/* Social Links in Contact */}
            <div className="mt-8 pt-6 border-t border-border">
              <p className={`text-sm text-muted-foreground mb-4 ${isRTL ? "text-right" : ""}`}>
                Follow me on social media
              </p>
              <div className={`flex gap-3 ${isRTL ? "justify-end" : ""}`}>
                <a
                  href="https://www.instagram.com/m_saji90/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-lg bg-accent/10 border border-accent/30 flex items-center justify-center hover:bg-accent/20 transition-colors"
                  aria-label="Instagram"
                >
                  <svg className="w-5 h-5 text-accent" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                  </svg>
                </a>
                <a
                  href="https://www.linkedin.com/in/sajid-iqbal90"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-lg bg-accent/10 border border-accent/30 flex items-center justify-center hover:bg-accent/20 transition-colors"
                  aria-label="LinkedIn"
                >
                  <svg className="w-5 h-5 text-accent" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                  </svg>
                </a>
                <a
                  href="https://www.behance.net/mahersajid"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-lg bg-accent/10 border border-accent/30 flex items-center justify-center hover:bg-accent/20 transition-colors"
                  aria-label="Behance"
                >
                  <svg className="w-5 h-5 text-accent" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M22 7h-7v-2h7v2zm1.726 10c-.442 1.297-2.029 3-5.101 3-3.074 0-5.564-1.729-5.564-5.675 0-3.91 2.325-5.92 5.466-5.92 3.082 0 4.964 1.782 5.375 4.426.078.506.109 1.188.095 2.14h-8.027c.13 3.211 3.483 3.312 4.588 2.029h3.168zm-7.686-4h4.965c-.105-1.547-1.136-2.219-2.477-2.219-1.466 0-2.277.768-2.488 2.219zm-9.574 6.988h-6.466v-14.967h6.953c5.476.081 5.58 5.444 2.72 6.906 3.461 1.26 3.577 8.061-3.207 8.061zm-3.466-8.988h3.584c2.508 0 2.906-3-.312-3h-3.272v3zm3.391 3h-3.391v3.016h3.341c3.055 0 2.868-3.016.05-3.016z" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
