"use client"

import { useEffect, useState, useRef } from "react"
import { ArrowRight, TrendingUp, Users, Target, Zap, Star, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/components/language-provider"

// Animated counter component
function AnimatedCounter({ end, suffix = "", duration = 2000 }: { end: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!isVisible) return
    let start = 0
    const increment = end / (duration / 16)
    const timer = setInterval(() => {
      start += increment
      if (start >= end) {
        setCount(end)
        clearInterval(timer)
      } else {
        setCount(Math.floor(start))
      }
    }, 16)
    return () => clearInterval(timer)
  }, [isVisible, end, duration])

  return (
    <div ref={ref} className="text-2xl sm:text-3xl lg:text-4xl font-bold text-accent font-serif">
      {count}
      {suffix}
    </div>
  )
}

// Mini chart component
function MiniChart() {
  const data = [30, 45, 35, 60, 50, 75, 65, 90, 85, 100]
  const maxValue = Math.max(...data)

  return (
    <div className="flex items-end gap-0.5 sm:gap-1 h-12 sm:h-16">
      {data.map((value, i) => (
        <div
          key={i}
          className="w-2 sm:w-3 bg-accent/80 rounded-t transition-all duration-500"
          style={{
            height: `${(value / maxValue) * 100}%`,
            animationDelay: `${i * 100}ms`,
          }}
        />
      ))}
    </div>
  )
}

// Growth graph SVG
function GrowthGraph() {
  return (
    <svg viewBox="0 0 200 100" className="w-full h-16 sm:h-24">
      <defs>
        <linearGradient id="graphGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.3" />
          <stop offset="100%" stopColor="var(--accent)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path
        d="M0 80 Q30 75 50 60 T100 40 T150 25 T200 10"
        fill="none"
        stroke="var(--accent)"
        strokeWidth="3"
        className="animate-draw-line"
        style={{ stroke: "oklch(0.7 0.2 45)" }}
      />
      <path d="M0 80 Q30 75 50 60 T100 40 T150 25 T200 10 L200 100 L0 100 Z" fill="url(#graphGradient)" opacity="0.5" />
    </svg>
  )
}

export function Hero() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const { t, isRTL } = useLanguage()

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  const scrollToContact = () => {
    const contactSection = document.getElementById("contact")
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-16 sm:pt-20 overflow-hidden"
    >
      {/* Animated background gradients */}
      <div className="absolute inset-0">
        <div
          className="absolute w-[300px] sm:w-[600px] h-[300px] sm:h-[600px] bg-primary/10 rounded-full blur-3xl animate-pulse-glow"
          style={{
            left: `${mousePosition.x * 0.02}px`,
            top: `${mousePosition.y * 0.02}px`,
          }}
        />
        <div className="absolute bottom-0 right-0 w-[250px] sm:w-[500px] h-[250px] sm:h-[500px] bg-accent/10 rounded-full blur-3xl animate-pulse-glow" />
      </div>

      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,var(--border)_1px,transparent_1px),linear-gradient(to_bottom,var(--border)_1px,transparent_1px)] bg-[size:40px_40px] sm:bg-[size:60px_60px] opacity-30" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className={`grid lg:grid-cols-2 gap-8 lg:gap-12 items-center ${isRTL ? "direction-rtl" : ""}`}>
          {/* Left Content */}
          <div className={`${isRTL ? "text-right" : "text-left"}`}>
            {/* Badge */}
            <div
              className={`inline-flex items-center gap-2 bg-accent/10 border border-accent/30 rounded-full px-3 sm:px-4 py-1.5 sm:py-2 mb-4 sm:mb-6 animate-fade-in-up ${isRTL ? "flex-row-reverse" : ""}`}
            >
              <Star className="w-3 h-3 sm:w-4 sm:h-4 text-accent" />
              <span className="text-xs sm:text-sm text-accent font-medium">{t.hero.badge}</span>
            </div>

            <h1
              className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-4 sm:mb-6 leading-tight animate-fade-in-up"
              style={{ animationDelay: "0.1s" }}
            >
              {t.hero.title} <span className="text-accent italic">{t.hero.titleHighlight}</span>
            </h1>

            {/* Pain Point Subheading */}
            <p
              className="text-base sm:text-lg md:text-xl text-muted-foreground mb-3 sm:mb-4 leading-relaxed animate-fade-in-up"
              style={{ animationDelay: "0.2s" }}
            >
              <strong className="text-foreground">{t.hero.subtitle}</strong> {t.hero.description}
            </p>

            <div
              className={`flex flex-col sm:flex-row items-stretch sm:items-start gap-3 sm:gap-4 mb-8 sm:mb-10 animate-fade-in-up ${isRTL ? "sm:flex-row-reverse" : ""}`}
              style={{ animationDelay: "0.4s" }}
            >
              <Button
                size="lg"
                onClick={scrollToContact}
                className={`bg-accent text-accent-foreground hover:bg-accent/90 px-6 sm:px-8 py-5 sm:py-6 text-base sm:text-lg group shadow-xl animate-glow w-full sm:w-auto ${isRTL ? "flex-row-reverse" : ""}`}
              >
                {t.hero.cta}
                <ArrowRight
                  className={`w-4 h-4 sm:w-5 sm:h-5 ${isRTL ? "mr-2 group-hover:-translate-x-1" : "ml-2 group-hover:translate-x-1"} transition-transform`}
                />
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => document.getElementById("portfolio")?.scrollIntoView({ behavior: "smooth" })}
                className="border-primary/50 text-foreground hover:bg-primary/10 px-6 sm:px-8 py-5 sm:py-6 text-base sm:text-lg bg-transparent w-full sm:w-auto"
              >
                {t.hero.ctaSecondary}
              </Button>
            </div>

            <div
              className={`flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6 text-xs sm:text-sm text-muted-foreground animate-fade-in-up ${isRTL ? "sm:flex-row-reverse" : ""}`}
              style={{ animationDelay: "0.5s" }}
            >
              <div className={`flex items-center gap-2 ${isRTL ? "flex-row-reverse" : ""}`}>
                <div className={`flex ${isRTL ? "space-x-reverse -space-x-2" : "-space-x-2"}`}>
                  {[1, 2, 3, 4].map((i) => (
                    <div
                      key={i}
                      className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-primary/20 border-2 border-background flex items-center justify-center text-xs font-bold text-primary"
                    >
                      {["A", "B", "C", "D"][i - 1]}
                    </div>
                  ))}
                </div>
                <span>{t.hero.happyClients}</span>
              </div>
              <div className={`flex items-center gap-1 ${isRTL ? "flex-row-reverse" : ""}`}>
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star key={i} className="w-3 h-3 sm:w-4 sm:h-4 fill-accent text-accent" />
                ))}
                <span className={`${isRTL ? "mr-1" : "ml-1"}`}>{t.hero.rating}</span>
              </div>
            </div>
          </div>

          {/* Right Content - Stats & Visuals */}
          <div className="relative animate-slide-in-right mt-8 lg:mt-0">
            {/* Main Stats Card */}
            <div className="bg-card border border-border rounded-2xl p-4 sm:p-6 shadow-2xl">
              {/* Growth Graph */}
              <div className="mb-4 sm:mb-6">
                <div className={`flex items-center justify-between mb-2 ${isRTL ? "flex-row-reverse" : ""}`}>
                  <span className="text-xs sm:text-sm text-muted-foreground">{t.hero.brandGrowth}</span>
                  <div className={`flex items-center gap-1 text-green-500 ${isRTL ? "flex-row-reverse" : ""}`}>
                    <ChevronUp className="w-3 h-3 sm:w-4 sm:h-4" />
                    <span className="text-xs sm:text-sm font-semibold">+247%</span>
                  </div>
                </div>
                <GrowthGraph />
              </div>

              <div className="grid grid-cols-2 gap-2 sm:gap-4">
                <div className="bg-background rounded-xl p-3 sm:p-4 border border-border">
                  <div
                    className={`flex items-center gap-1.5 sm:gap-2 mb-1.5 sm:mb-2 ${isRTL ? "flex-row-reverse" : ""}`}
                  >
                    <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-lg bg-accent/20 flex items-center justify-center">
                      <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4 text-accent" />
                    </div>
                    <span className="text-[10px] sm:text-xs text-muted-foreground truncate">{t.hero.engagement}</span>
                  </div>
                  <AnimatedCounter end={312} suffix="%" />
                  <span className="text-[10px] sm:text-xs text-green-500">{t.hero.engagementLabel}</span>
                </div>

                <div className="bg-background rounded-xl p-3 sm:p-4 border border-border">
                  <div
                    className={`flex items-center gap-1.5 sm:gap-2 mb-1.5 sm:mb-2 ${isRTL ? "flex-row-reverse" : ""}`}
                  >
                    <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                      <Users className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                    </div>
                    <span className="text-[10px] sm:text-xs text-muted-foreground truncate">{t.hero.projects}</span>
                  </div>
                  <AnimatedCounter end={150} suffix="+" />
                  <span className="text-[10px] sm:text-xs text-muted-foreground">{t.hero.projectsLabel}</span>
                </div>

                <div className="bg-background rounded-xl p-3 sm:p-4 border border-border">
                  <div
                    className={`flex items-center gap-1.5 sm:gap-2 mb-1.5 sm:mb-2 ${isRTL ? "flex-row-reverse" : ""}`}
                  >
                    <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-lg bg-green-500/20 flex items-center justify-center">
                      <Target className="w-3 h-3 sm:w-4 sm:h-4 text-green-500" />
                    </div>
                    <span className="text-[10px] sm:text-xs text-muted-foreground truncate">{t.hero.conversion}</span>
                  </div>
                  <AnimatedCounter end={89} suffix="%" />
                  <span className="text-[10px] sm:text-xs text-muted-foreground">{t.hero.conversionLabel}</span>
                </div>

                <div className="bg-background rounded-xl p-3 sm:p-4 border border-border">
                  <div
                    className={`flex items-center gap-1.5 sm:gap-2 mb-1.5 sm:mb-2 ${isRTL ? "flex-row-reverse" : ""}`}
                  >
                    <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
                      <Zap className="w-3 h-3 sm:w-4 sm:h-4 text-purple-500" />
                    </div>
                    <span className="text-[10px] sm:text-xs text-muted-foreground truncate">{t.hero.turnaround}</span>
                  </div>
                  <AnimatedCounter end={48} suffix="h" />
                  <span className="text-[10px] sm:text-xs text-muted-foreground">{t.hero.turnaroundLabel}</span>
                </div>
              </div>

              {/* Mini Chart */}
              <div className="mt-4 sm:mt-6 pt-3 sm:pt-4 border-t border-border">
                <div className={`flex items-center justify-between mb-2 ${isRTL ? "flex-row-reverse" : ""}`}>
                  <span className="text-xs sm:text-sm text-muted-foreground">{t.hero.monthlyGrowth}</span>
                  <span className="text-[10px] sm:text-xs text-green-500 font-medium">{t.hero.thisMonth}</span>
                </div>
                <MiniChart />
              </div>
            </div>

            <div
              className={`absolute -top-2 sm:-top-4 ${isRTL ? "-left-2 sm:-left-4" : "-right-2 sm:-right-4"} bg-accent text-accent-foreground rounded-full px-2 sm:px-4 py-1 sm:py-2 shadow-lg animate-float hidden sm:block`}
            >
              <span className="text-xs sm:text-sm font-bold">{t.hero.rated}</span>
            </div>

            <div
              className={`absolute -bottom-2 sm:-bottom-4 ${isRTL ? "-right-2 sm:-right-4" : "-left-2 sm:-left-4"} bg-card border border-border rounded-xl p-2 sm:p-3 shadow-lg animate-float hidden sm:block`}
              style={{ animationDelay: "0.5s" }}
            >
              <div className={`flex items-center gap-2 ${isRTL ? "flex-row-reverse" : ""}`}>
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-green-500" />
                </div>
                <div className={`${isRTL ? "text-right" : ""}`}>
                  <p className="text-[10px] sm:text-xs text-muted-foreground">{t.hero.revenueImpact}</p>
                  <p className="text-xs sm:text-sm font-bold text-green-500">+$50K+</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
