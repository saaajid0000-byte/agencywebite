"use client"

import { useEffect, useRef, useState } from "react"
import { CheckCircle2, Sparkles, Zap, Palette, Target, Brain, TrendingUp, ArrowRight, Rocket } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/components/language-provider"

const solutionIcons = [Zap, Target, Palette, Brain, TrendingUp, Rocket]

export function Solution() {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const { t, isRTL } = useLanguage()

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={ref} className="py-24 bg-background relative overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 ${isRTL ? "direction-rtl" : ""}`}>
          <div
            className={`inline-flex items-center gap-2 bg-accent/10 border border-accent/30 rounded-full px-4 py-2 mb-6 ${isRTL ? "flex-row-reverse" : ""}`}
          >
            <Sparkles className="w-4 h-4 text-accent" />
            <span className="text-sm text-accent font-medium">{t.solution.badge}</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
            {t.solution.title}
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty">{t.solution.description}</p>
        </div>

        {/* Solutions Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {t.solution.solutions.map((solution, index) => {
            const Icon = solutionIcons[index]
            return (
              <div
                key={index}
                className={`group relative p-6 bg-card border border-border rounded-xl hover:border-accent/50 transition-all duration-500 overflow-hidden ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />

                <div className={`relative ${isRTL ? "text-right" : ""}`}>
                  <div
                    className={`w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors ${isRTL ? "mr-auto ml-0" : ""}`}
                  >
                    <Icon className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{solution.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{solution.description}</p>
                  <div className={`flex items-center gap-2 ${isRTL ? "flex-row-reverse" : ""}`}>
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-green-500 font-medium">{solution.benefit}</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Process Section */}
        <div className="bg-card border border-border rounded-2xl p-8 md:p-12">
          <div className={`text-center mb-12 ${isRTL ? "direction-rtl" : ""}`}>
            <h3 className="font-serif text-2xl md:text-3xl font-bold text-foreground mb-2">
              {t.solution.processTitle}
            </h3>
            <p className="text-muted-foreground">{t.solution.processSubtitle}</p>
          </div>

          <div className={`grid sm:grid-cols-2 lg:grid-cols-4 gap-6 ${isRTL ? "direction-rtl" : ""}`}>
            {t.solution.process.map((item, index) => (
              <div key={index} className="text-center relative">
                <div className="w-16 h-16 mx-auto rounded-full bg-accent/10 border-2 border-accent flex items-center justify-center mb-4">
                  <span className="text-xl font-bold text-accent">{String(index + 1).padStart(2, "0")}</span>
                </div>
                <h4 className="font-semibold text-foreground mb-1">{item.title}</h4>
                <p className="text-sm text-muted-foreground">{item.desc}</p>

                {index < t.solution.process.length - 1 && (
                  <div className={`hidden lg:block absolute top-8 ${isRTL ? "right-[60%]" : "left-[60%]"} w-[80%]`}>
                    <ArrowRight className={`w-6 h-6 text-accent/30 ${isRTL ? "rotate-180" : ""}`} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Button
            size="lg"
            className={`bg-accent text-accent-foreground hover:bg-accent/90 px-8 py-6 text-lg shadow-xl animate-glow group ${isRTL ? "flex-row-reverse" : ""}`}
          >
            {t.solution.cta}
            <ArrowRight
              className={`w-5 h-5 ${isRTL ? "mr-2 group-hover:-translate-x-1" : "ml-2 group-hover:translate-x-1"} transition-transform`}
            />
          </Button>
          <p className="text-sm text-muted-foreground mt-4">{t.solution.ctaSubtext}</p>
        </div>
      </div>
    </section>
  )
}
