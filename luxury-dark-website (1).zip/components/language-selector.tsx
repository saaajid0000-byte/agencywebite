"use client"

import { useState, useRef, useEffect } from "react"
import { Globe, ChevronDown } from "lucide-react"
import { useLanguage } from "./language-provider"
import type { Language } from "@/lib/translations"

export function LanguageSelector() {
  const { language, setLanguage, languageNames } = useLanguage()
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const languages = Object.entries(languageNames) as [Language, string][]

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg bg-accent/10 border border-accent/30 hover:bg-accent/20 transition-colors text-sm"
        aria-label="Select language"
      >
        <Globe className="w-4 h-4 text-accent" />
        <span className="text-foreground">{languageNames[language]}</span>
        <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full mt-2 right-0 bg-card border border-border rounded-xl shadow-xl z-50 overflow-hidden min-w-[160px] animate-fade-in-up">
          {languages.map(([code, name]) => (
            <button
              key={code}
              onClick={() => {
                setLanguage(code)
                setIsOpen(false)
              }}
              className={`w-full px-4 py-2.5 text-left text-sm hover:bg-accent/10 transition-colors flex items-center justify-between ${
                language === code ? "bg-accent/10 text-accent" : "text-foreground"
              }`}
            >
              <span>{name}</span>
              {language === code && <span className="w-2 h-2 rounded-full bg-accent" />}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
