"use client"

import { Sparkles, PenTool, Palette, Target, Calendar, ArrowRight, Layers } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useLanguage } from "@/components/language-provider"

const serviceIcons = [PenTool, Palette, Sparkles, Target, Calendar, Layers]

export function Services() {
  const { t, isRTL } = useLanguage()

  const servicesListWithExtra = [
    ...t.services.servicesList,
    {
      title: "Presentation & Pitch Deck Design",
      description:
        "Professional presentation designs that captivate investors and clients. Clean slides, compelling visuals, and strategic storytelling for maximum impact.",
    },
  ]

  return (
    <section id="services" className="py-16 sm:py-24 bg-card border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-10 sm:mb-16 ${isRTL ? "direction-rtl" : ""}`}>
          <div
            className={`inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-3 sm:px-4 py-1.5 sm:py-2 mb-4 sm:mb-6 ${isRTL ? "flex-row-reverse" : ""}`}
          >
            <Sparkles className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
            <span className="text-xs sm:text-sm text-primary font-medium">{t.services.badge}</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-3 sm:mb-4 text-balance">
            {t.services.title}
          </h2>
          <p className="text-sm sm:text-base lg:text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            {t.services.description}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {servicesListWithExtra.map((service, index) => {
            const Icon = serviceIcons[index] || Layers
            return (
              <Card
                key={index}
                className="group bg-background border-border hover:border-primary/50 transition-all duration-300 overflow-hidden"
              >
                <CardHeader className={`p-4 sm:p-6 ${isRTL ? "text-right" : ""}`}>
                  <div
                    className={`w-10 h-10 sm:w-14 sm:h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-3 sm:mb-4 group-hover:bg-primary/20 group-hover:scale-110 transition-all duration-300 ${isRTL ? "mr-auto ml-0" : ""}`}
                  >
                    <Icon className="w-5 h-5 sm:w-7 sm:h-7 text-primary" />
                  </div>
                  <CardTitle className="text-base sm:text-lg lg:text-xl font-semibold text-foreground">
                    {service.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className={`p-4 sm:p-6 pt-0 ${isRTL ? "text-right" : ""}`}>
                  <CardDescription className="text-muted-foreground text-xs sm:text-sm lg:text-base leading-relaxed">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Benefits List */}
        <div className="mt-12 sm:mt-20 bg-background border border-border rounded-2xl p-5 sm:p-8 md:p-12">
          <h3
            className={`font-serif text-xl sm:text-2xl md:text-3xl font-bold text-foreground mb-6 sm:mb-8 text-center ${isRTL ? "direction-rtl" : ""}`}
          >
            {t.services.benefitsTitle}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {t.services.benefits.map((benefit, index) => (
              <div
                key={index}
                className={`flex items-start gap-2 sm:gap-3 ${isRTL ? "flex-row-reverse text-right" : ""}`}
              >
                <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <ArrowRight className={`w-2.5 h-2.5 sm:w-3 sm:h-3 text-primary ${isRTL ? "rotate-180" : ""}`} />
                </div>
                <span className="text-foreground text-sm sm:text-base">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
